﻿Imports System.Data.SqlClient
Public Class userLogin
    Dim table As New DataTable
    Dim conn As New SqlConnection("server =DESKTOP-N7870M5; database = CAR RENTING SYSTEM DB; Integrated security= True")
    Private Sub userLogin_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.Text = "USER LOGIN"
        Me.MaximizeBox = False
        Me.Hide()
    End Sub

    Private Sub LoginUsernameBTN_Click(sender As Object, e As EventArgs) Handles LoginUsernameBTN.Click
        If TextBox1.Text = String.Empty And TextBox2.Text = String.Empty Then
            MsgBox("Username And Password is Empty ", MsgBoxStyle.Information, "     USER LOGIN ")
        ElseIf TextBox1.Text = String.Empty Then
            MsgBox("Please Enter your Username ", MsgBoxStyle.Information, "     USER LOGIN")
        ElseIf TextBox2.Text = String.Empty Then
            MsgBox("Please Enter your Password", MsgBoxStyle.Information, "     USER LOGIN ")
        Else
            Dim command As New SqlCommand("select * from Userinformation where Username = @Username and Password=@Password", conn)

            command.Parameters.Add("@Username", SqlDbType.VarChar).Value = TextBox1.Text
            command.Parameters.Add("@Password", SqlDbType.VarChar).Value = TextBox2.Text
            Dim adapter As New SqlDataAdapter(command)
            adapter.Fill(table)

            If table.Rows.Count() <= 0 Then
                MsgBox("Your Username or Password is INCORRECT", MsgBoxStyle.Critical)

            Else
                Book.Show()

                Book.TextBox1.Text = table(0)(0)
                Book.TextBox2.Text = table(0)(1)
                Book.TextBox3.Text = table(0)(3)
                Book.TextBox4.Text = table(0)(5)
                Book.TextBox5.Text = table(0)(10)
                Book.TextBox6.Text = table(0)(9)
                Me.Hide()
                TextBox1.Clear()
                TextBox2.Clear()
            End If
        End If
    End Sub

    Private Sub ShowPassword_Click(sender As Object, e As EventArgs) Handles ShowPassword.Click

        If TextBox2.UseSystemPasswordChar = True Then
            TextBox2.UseSystemPasswordChar = False
        Else
            TextBox2.UseSystemPasswordChar = True
        End If
    End Sub


    Private Sub GroupBox1_Enter(sender As Object, e As EventArgs) Handles GroupBox1.Enter
        TextBox2.UseSystemPasswordChar = True
    End Sub

    Private Sub CancelUsernameBTN_Click(sender As Object, e As EventArgs) Handles CancelUsernameBTN.Click
        Close()
        loginboth.Show()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles createAccountBTN.Click
        UserRegistration.Show()
        Me.Hide()
    End Sub

End Class