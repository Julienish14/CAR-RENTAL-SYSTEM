﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class fullform
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(fullform))
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.BookBTN = New System.Windows.Forms.Button()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.PrintBTN = New System.Windows.Forms.Button()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.PrintDocument1 = New System.Drawing.Printing.PrintDocument()
        Me.PrintPreviewDialog1 = New System.Windows.Forms.PrintPreviewDialog()
        Me.OkBTN = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TxtboxNumberofday = New System.Windows.Forms.TextBox()
        Me.TextBoxDATEofRet = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        Me.ErrorProvider1 = New System.Windows.Forms.ErrorProvider(Me.components)
        Me.GroupBox2.SuspendLayout()
        CType(Me.ErrorProvider1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.BackColor = System.Drawing.Color.Transparent
        Me.Label17.Font = New System.Drawing.Font("Bernard MT Condensed", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.Label17.Location = New System.Drawing.Point(233, 134)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(170, 25)
        Me.Label17.TabIndex = 30
        Me.Label17.Text = "Rent with Driver :"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.BackColor = System.Drawing.Color.Transparent
        Me.Label16.Font = New System.Drawing.Font("Bernard MT Condensed", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(233, 169)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(154, 25)
        Me.Label16.TabIndex = 29
        Me.Label16.Text = "Number of Day :"
        '
        'BookBTN
        '
        Me.BookBTN.BackColor = System.Drawing.Color.DarkRed
        Me.BookBTN.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BookBTN.Font = New System.Drawing.Font("Algerian", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BookBTN.ForeColor = System.Drawing.SystemColors.ControlText
        Me.BookBTN.Location = New System.Drawing.Point(279, 240)
        Me.BookBTN.Name = "BookBTN"
        Me.BookBTN.Size = New System.Drawing.Size(180, 49)
        Me.BookBTN.TabIndex = 33
        Me.BookBTN.Text = "CONFIRM"
        Me.BookBTN.UseVisualStyleBackColor = False
        '
        'ComboBox1
        '
        Me.ComboBox1.BackColor = System.Drawing.Color.Black
        Me.ErrorProvider1.SetError(Me.ComboBox1, "YES Or NO ")
        Me.ComboBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox1.ForeColor = System.Drawing.Color.White
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Items.AddRange(New Object() {"YES", "NO"})
        Me.ComboBox1.Location = New System.Drawing.Point(409, 131)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(93, 28)
        Me.ComboBox1.TabIndex = 34
        Me.ComboBox1.TabStop = False
        '
        'PrintBTN
        '
        Me.PrintBTN.BackColor = System.Drawing.Color.Transparent
        Me.PrintBTN.Enabled = False
        Me.PrintBTN.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.PrintBTN.Font = New System.Drawing.Font("Impact", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PrintBTN.ForeColor = System.Drawing.SystemColors.ControlText
        Me.PrintBTN.Location = New System.Drawing.Point(290, 295)
        Me.PrintBTN.Name = "PrintBTN"
        Me.PrintBTN.Size = New System.Drawing.Size(137, 53)
        Me.PrintBTN.TabIndex = 36
        Me.PrintBTN.Text = "PRINT"
        Me.PrintBTN.UseVisualStyleBackColor = False
        Me.PrintBTN.Visible = False
        '
        'TextBox2
        '
        Me.TextBox2.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.TextBox2.BackColor = System.Drawing.SystemColors.ActiveBorder
        Me.TextBox2.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox2.Cursor = System.Windows.Forms.Cursors.No
        Me.TextBox2.Font = New System.Drawing.Font("Imprint MT Shadow", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox2.Location = New System.Drawing.Point(221, 170)
        Me.TextBox2.Multiline = True
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.ReadOnly = True
        Me.TextBox2.Size = New System.Drawing.Size(292, 95)
        Me.TextBox2.TabIndex = 37
        Me.TextBox2.TabStop = False
        Me.TextBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.TextBox2.Visible = False
        '
        'GroupBox1
        '
        Me.GroupBox1.Location = New System.Drawing.Point(221, 39)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(132, 19)
        Me.GroupBox1.TabIndex = 38
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Visible = False
        '
        'PrintDocument1
        '
        '
        'PrintPreviewDialog1
        '
        Me.PrintPreviewDialog1.AutoScrollMargin = New System.Drawing.Size(0, 0)
        Me.PrintPreviewDialog1.AutoScrollMinSize = New System.Drawing.Size(0, 0)
        Me.PrintPreviewDialog1.ClientSize = New System.Drawing.Size(400, 300)
        Me.PrintPreviewDialog1.Document = Me.PrintDocument1
        Me.PrintPreviewDialog1.Enabled = True
        Me.PrintPreviewDialog1.Icon = CType(resources.GetObject("PrintPreviewDialog1.Icon"), System.Drawing.Icon)
        Me.PrintPreviewDialog1.Name = "PrintPreviewDialog1"
        Me.PrintPreviewDialog1.Visible = False
        '
        'OkBTN
        '
        Me.OkBTN.BackColor = System.Drawing.Color.Transparent
        Me.OkBTN.Enabled = False
        Me.OkBTN.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.OkBTN.Font = New System.Drawing.Font("Algerian", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.OkBTN.ForeColor = System.Drawing.SystemColors.ControlText
        Me.OkBTN.Location = New System.Drawing.Point(290, 295)
        Me.OkBTN.Name = "OkBTN"
        Me.OkBTN.Size = New System.Drawing.Size(137, 53)
        Me.OkBTN.TabIndex = 39
        Me.OkBTN.Text = "OK"
        Me.OkBTN.UseVisualStyleBackColor = False
        Me.OkBTN.Visible = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(580, 175)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(0, 13)
        Me.Label1.TabIndex = 41
        '
        'TxtboxNumberofday
        '
        Me.TxtboxNumberofday.BackColor = System.Drawing.Color.Black
        Me.ErrorProvider1.SetError(Me.TxtboxNumberofday, "Enter Number of Days in NUMBER")
        Me.TxtboxNumberofday.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtboxNumberofday.ForeColor = System.Drawing.Color.White
        Me.TxtboxNumberofday.Location = New System.Drawing.Point(409, 169)
        Me.TxtboxNumberofday.Multiline = True
        Me.TxtboxNumberofday.Name = "TxtboxNumberofday"
        Me.TxtboxNumberofday.Size = New System.Drawing.Size(93, 31)
        Me.TxtboxNumberofday.TabIndex = 43
        '
        'TextBoxDATEofRet
        '
        Me.TextBoxDATEofRet.BackColor = System.Drawing.Color.Black
        Me.TextBoxDATEofRet.Font = New System.Drawing.Font("Trebuchet MS", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxDATEofRet.ForeColor = System.Drawing.Color.White
        Me.TextBoxDATEofRet.Location = New System.Drawing.Point(25, 58)
        Me.TextBoxDATEofRet.Name = "TextBoxDATEofRet"
        Me.TextBoxDATEofRet.Size = New System.Drawing.Size(151, 25)
        Me.TextBoxDATEofRet.TabIndex = 44
        Me.TextBoxDATEofRet.TabStop = False
        Me.TextBoxDATEofRet.Text = "Day to Return Car"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Imprint MT Shadow", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(67, 14)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(56, 15)
        Me.Label3.TabIndex = 46
        Me.Label3.Text = "To Day"
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox2.Controls.Add(Me.DateTimePicker1)
        Me.GroupBox2.Controls.Add(Me.Label3)
        Me.GroupBox2.Controls.Add(Me.TextBoxDATEofRet)
        Me.GroupBox2.Location = New System.Drawing.Point(545, 111)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(195, 89)
        Me.GroupBox2.TabIndex = 47
        Me.GroupBox2.TabStop = False
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.CustomFormat = "dd/MM/yyyy"
        Me.DateTimePicker1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.DateTimePicker1.Location = New System.Drawing.Point(50, 31)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(112, 21)
        Me.DateTimePicker1.TabIndex = 47
        Me.DateTimePicker1.TabStop = False
        '
        'ErrorProvider1
        '
        Me.ErrorProvider1.ContainerControl = Me
        '
        'fullform
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Black
        Me.BackgroundImage = Global.CAR_RENTING_SYSTEM.My.Resources.Resources.GTT90
        Me.ClientSize = New System.Drawing.Size(752, 394)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.TxtboxNumberofday)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.ComboBox1)
        Me.Controls.Add(Me.BookBTN)
        Me.Controls.Add(Me.OkBTN)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.PrintBTN)
        Me.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Location = New System.Drawing.Point(550, 550)
        Me.Name = "fullform"
        Me.Text = "fullform"
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.ErrorProvider1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label17 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents BookBTN As Button
    Friend WithEvents ComboBox1 As ComboBox
    Friend WithEvents PrintBTN As Button
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents PrintDocument1 As Printing.PrintDocument
    Friend WithEvents PrintPreviewDialog1 As PrintPreviewDialog
    Friend WithEvents OkBTN As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents TxtboxNumberofday As TextBox
    Friend WithEvents TextBoxDATEofRet As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents DateTimePicker1 As DateTimePicker
    Friend WithEvents ErrorProvider1 As ErrorProvider
End Class
