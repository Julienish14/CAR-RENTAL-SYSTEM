﻿Imports System.Data.SqlClient
Public Class adminLogin
    Dim connection As New SqlConnection("Server = DESKTOP-N7870M5; Database = CAR RENTING SYSTEM DB; Integrated Security = true")

    Private Sub loginAdmnBtn_Click(sender As Object, e As EventArgs) Handles loginAdmnBtn.Click

        If TextboxAdmin.Text = String.Empty And TextAdminPassword.Text = String.Empty Then
            MsgBox("Admin Username And Password is Empty ", MsgBoxStyle.Information, "ADMIN LOGIN ")
        ElseIf TextboxAdmin.Text = String.Empty Then
            MsgBox("Please Enter Your Username ", MsgBoxStyle.Information, "ADMIN LOGIN")
        ElseIf TextAdminPassword.Text = String.Empty Then
            MsgBox("Please Enter Your Password", MsgBoxStyle.Information, "ADMIN LOGIN ")
        Else

            Dim command As New SqlCommand("select * from Admininformation where Admin_Name = @Admin_Name and Password = @Password ", connection)

            command.Parameters.Add("@Admin_Name", SqlDbType.VarChar).Value = TextboxAdmin.Text
            command.Parameters.Add("@Password", SqlDbType.VarChar).Value = TextAdminPassword.Text

            Dim adapter As New SqlDataAdapter(command)

            Dim table As New DataTable()

            adapter.Fill(table)

            If table.Rows.Count() <= 0 Then
                MsgBox("Your UserName Or Password is Incorrect", MsgBoxStyle.Exclamation)
            Else
                AdminTask.Show()
                Me.Hide()
                TextboxAdmin.Clear()
                TextAdminPassword.Clear()

                CheckForBooker.TextBoxCampanyNa.Text = table(0)(0)
                CheckForBooker.TextBoxContactN.Text = table(0)(1)
                CheckForBooker.TextBoxEmail.Text = table(0)(2)
                CheckForBooker.TextBoxLocation.Text = table(0)(3)
            End If
        End If
    End Sub


    Private Sub cancelAdminBtn_Click(sender As Object, e As EventArgs) Handles cancelAdminBtn.Click
        Close()
        loginboth.Show()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If TextAdminPassword.UseSystemPasswordChar = True Then
            TextAdminPassword.UseSystemPasswordChar = False
        Else
            TextAdminPassword.UseSystemPasswordChar = True
        End If
    End Sub

    Private Sub GroupBox1_Enter(sender As Object, e As EventArgs) Handles GroupBox1.Enter
        TextAdminPassword.UseSystemPasswordChar = True
    End Sub

    Private Sub adminLogin_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.MaximizeBox = False
        Me.Text = "ADMIN LOGIN
"
    End Sub
End Class