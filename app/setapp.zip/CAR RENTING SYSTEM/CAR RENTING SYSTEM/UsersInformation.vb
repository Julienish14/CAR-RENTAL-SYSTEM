﻿Imports System.Data.SqlClient
Public Class UsersInformation
    Dim con As New SqlConnection("Server = DESKTOP-N7870M5; Database = CAR RENTING SYSTEM DB; Integrated Security = true")



    Private Sub DeleteuserBTN_Click(sender As Object, e As EventArgs) Handles DeleteuserBTN.Click
        Dim command As New SqlCommand("delete from Userinformation where Firstname = @Firstname", con)
        command.Parameters.Add("@Firstname", SqlDbType.VarChar).Value = TextBox1.Text

        Dim adapter As New SqlDataAdapter(command)

        Dim table As New DataTable()

        adapter.Fill(table)

        If table.Rows.Count() <= 0 Then
            MessageBox.Show("USER   " + TextBox1.Text + "  " + TextBox2.Text + "WITH IDNUMBER" + TextBox10.Text + "  DELETED ")
            Load_data("")
        Else
            MessageBox.Show("USER not Deleted")
        End If


    End Sub

    Private Sub UsersInformation_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'CAR_RENTING_SYSTEM_DBDataSet7.Userinformation' table. You can move, or remove it, as needed.
        Me.UserinformationTableAdapter1.Fill(Me.CAR_RENTING_SYSTEM_DBDataSet7.Userinformation)
        'TODO: This line of code loads data into the 'CAR_RENTING_SYSTEM_DBDataSet1.Userinformation' table. You can move, or remove it, as needed.

        Me.Text = "USER INFORMATION"
    End Sub
    Sub Load_data(ByVal search As String)
        Dim query As String = "SELECT * FROM Userinformation"
        Dim cmd As New SqlCommand
        cmd = New SqlCommand(query, con)
        Dim da = New SqlDataAdapter(cmd)
        Dim dt As New DataTable
        da.Fill(dt)
        DataGridView1.DataSource = dt
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        Try
            Dim i As Integer
            i = DataGridView1.CurrentRow.Index
            Me.TextBox1.Text = DataGridView1.Item(0, i).Value
            Me.TextBox2.Text = DataGridView1.Item(1, i).Value
            Me.TextBox3.Text = DataGridView1.Item(2, i).Value
            Me.TextBox4.Text = DataGridView1.Item(3, i).Value
            Me.TextBox5.Text = DataGridView1.Item(5, i).Value
            Me.TextBox6.Text = DataGridView1.Item(6, i).Value
            Me.TextBox7.Text = DataGridView1.Item(7, i).Value
            Me.TextBox8.Text = DataGridView1.Item(8, i).Value
            Me.TextBox9.Text = DataGridView1.Item(9, i).Value
            Me.TextBox10.Text = DataGridView1.Item(10, i).Value
            DeleteuserBTN.Visible = True

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub SearchBTN_Click(sender As Object, e As EventArgs) Handles SearchBTN.Click
        Dim command As New SqlCommand("select * from Userinformation where IDNumber = @IDNumber", con)
        command.Parameters.Add("@IDNumber", SqlDbType.VarChar).Value = TextBox11.Text

        Dim adapter As New SqlDataAdapter(command)
        Dim table As New DataTable()
        adapter.Fill(table)
        DataGridView1.DataSource = table
    End Sub
End Class