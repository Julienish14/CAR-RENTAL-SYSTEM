﻿Imports System.Data.SqlClient
Imports System.IO
Public Class CheckForBooker

    Dim con As New SqlConnection("server = DESKTOP-N7870M5;Database= CAR RENTING SYSTEM DB; integrated security= true")

    Dim carstatus As String = ""
    Private Sub ConfrmBookerBTN_Click(sender As Object, e As EventArgs) Handles ConfrmBookerBTN.Click
        Dim com As New SqlCommand("INSERT INTO CarReport (IDNumber,Firstname,Surname,ContactNo,PlateNumber,Manufacture,Model,PricePerDay,RentWithDrive,NumberOfDays,TotalPrice,TransactionCode,DateOfRenting,DateRetunCar)
     VALUES (@IDNumber,@Firstname,@Surname,@ContactNo,@PlateNumber,@Manufacture,@Model,@PricePerDay,@RentWithDrive,@NumberOfDays,@TotalPrice,@TransactionCode,@DateOfRenting,@DateRetunCar)", con)

        com.Parameters.Add("@IDNumber", SqlDbType.VarChar).Value = TextBoxIDNumber.Text
        com.Parameters.Add("@Firstname", SqlDbType.VarChar).Value = TextBoxFirstname.Text
        com.Parameters.Add("@Surname", SqlDbType.VarChar).Value = TextBoxSurname.Text
        com.Parameters.Add("@ContactNo", SqlDbType.VarChar).Value = TextBoxContactNumber.Text
        com.Parameters.Add("@PlateNumber", SqlDbType.VarChar).Value = TextBoxPlateNumber.Text
        com.Parameters.Add("@Manufacture", SqlDbType.VarChar).Value = TextBoxManufacture.Text
        com.Parameters.Add("@Model", SqlDbType.VarChar).Value = TextBoxModel.Text
        com.Parameters.Add("@PricePerDay", SqlDbType.VarChar).Value = TextBoxPircePerDay.Text
        com.Parameters.Add("@RentWithDrive", SqlDbType.VarChar).Value = TextBoxRentWithDriver.Text
        com.Parameters.Add("@NumberOfDays", SqlDbType.VarChar).Value = TextBoxNumberOfDay.Text
        com.Parameters.Add("@TotalPrice", SqlDbType.VarChar).Value = TextBoxTotolPric.Text
        com.Parameters.Add("@TransactionCode", SqlDbType.VarChar).Value = TextBoxTcode.Text
        com.Parameters.Add("@DateOfRenting", SqlDbType.Date).Value = TextBoxDateOfRent.Text
        com.Parameters.Add("@DateRetunCar", SqlDbType.Date).Value = TextBoxDateOfReturn.Text

        con.Open()
        If com.ExecuteNonQuery = 1 Then
            MsgBox("  TRANSACTION  WITH   NUMBER   " + TextBoxTcode.Text + "  IS CONFIRMED", MsgBoxStyle.Information, "TRANSACTION CONFIRMATION")
        Else
            MessageBox.Show("UNCONFIRMED")
        End If
        con.Close()
        fullform.TextBox2.Text = TextBox16.Text
        fullform.PrintBTN.Enabled = True
        fullform.Label16.Visible = False
        fullform.Label17.Visible = False
        fullform.ComboBox1.Visible = False
        fullform.TxtboxNumberofday.Visible = False
        fullform.BookBTN.Visible = False
        fullform.TextBox2.Visible = True
        fullform.TextBox2.BackColor = Color.White
        fullform.TextBox2.ForeColor = Color.Black
        fullform.PrintBTN.Visible = True
        fullform.OkBTN.Visible = False
        fullform.PrintBTN.BackColor = Color.DarkSlateGray
        fullform.GroupBox2.Visible = False
        Me.Hide()
        fullform.Show()


    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles DenyBTN.Click
        fullform.TextBox2.Text = TextBox18.Text
        fullform.OkBTN.Enabled = True
        fullform.Show()
        fullform.TextBox2.Visible = True
        fullform.Label16.Visible = False
        fullform.Label17.Visible = False
        fullform.ComboBox1.Visible = False
        fullform.TxtboxNumberofday.Visible = False
        fullform.BookBTN.Visible = False
        fullform.TextBox2.Visible = True
        fullform.TextBox2.BackColor = Color.White
        fullform.TextBox2.ForeColor = Color.Black
        fullform.PrintBTN.Enabled = False
        fullform.OkBTN.Visible = True
        GroupBox2.Visible = False
        fullform.OkBTN.BackColor = Color.DarkSlateGray
        fullform.BookBTN.Enabled = False
        fullform.TextBox2.Enabled = True
        fullform.ComboBox1.Enabled = False
        fullform.GroupBox2.Visible = False
        Me.Hide()
        fullform.Show()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles UpdateStatusBTN.Click

        Dim updateQuery As String = "Update Carinformation Set CarStatus = '" & RadioButton3.Checked & "' WHERE PlateNumber = '" & TextBoxPlateNumber.Text & "' "
        ExecuteQuery(updateQuery)
        MsgBox("CAR   " + TextBoxModel.Text + "  PLATENUMBER   " + TextBoxPlateNumber.Text + "  
 IS REMOVED FROM THE AVAILABLE CAR LIST NOW ", MsgBoxStyle.Information, "CAR STATUS UPDATE")
        ConfrmBookerBTN.Visible = True
        DenyBTN.Visible = True
        UpdateStatusBTN.Visible = False
        RadioButton3.Visible = False
        RadioButton4.Visible = False


    End Sub
    Public Sub ExecuteQuery(Query As String)
        Dim command As New SqlCommand(Query, con)
        con.Open()
        command.ExecuteNonQuery()
        con.Close()
    End Sub

    Private Sub Checkbooker_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim date1 As String = Convert.ToDateTime(TextBoxDateOfRent.Text)
        TextBoxDateOfReturn.Text = fullform.TextBoxDATEofRet.Text
        Me.Text = "CHECK FOR BOOKER"

        If TextBoxRentWithDriver.Text = "YES" Then
            TextBoxSubTotalPrice.Text = (FormatCurrency(TextBoxPircePerDay.Text + 100) * TextBoxNumberOfDay.Text)
        ElseIf TextBoxRentWithDriver.Text = "NO" Then
            TextBoxSubTotalPrice.Text = (FormatCurrency(TextBoxPircePerDay.Text * TextBoxNumberOfDay.Text))
        Else
            MsgBox("Form of Number of Day OR Rent with Driver is not filled ", MsgBoxStyle.OkOnly, "ERROR")
        End If

        'DISCOUNT AND TOTALPRICE CALCULATION

        If TextBoxIDNumber.Text >= "A001" And TextBoxIDNumber.Text <= "A050" Then
            TextBoxDiscount.Text = (FormatCurrency(TextBoxSubTotalPrice.Text * 0.15))
            TextBoxTotolPric.Text = (FormatCurrency(TextBoxSubTotalPrice.Text - TextBoxDiscount.Text))
        ElseIf TextBoxIDNumber.Text >= "A051" And TextBoxIDNumber.Text <= "A100" Then
            TextBoxDiscount.Text = (FormatCurrency(TextBoxSubTotalPrice.Text * 0.1))
            TextBoxTotolPric.Text = (FormatCurrency(TextBoxSubTotalPrice.Text - TextBoxDiscount.Text))
        Else
            TextBoxDiscount.Text = (FormatCurrency(TextBoxSubTotalPrice.Text * 0.05))
            TextBoxTotolPric.Text = (FormatCurrency(TextBoxSubTotalPrice.Text - TextBoxDiscount.Text))
        End If

    End Sub

    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles TCodeBTN.Click


        Dim GetCode As String = "0"
        Dim cmd As New SqlCommand
        cmd = New SqlCommand
        cmd.Connection = con
        cmd.CommandText = "SELECT TOP(1) * FROM CarReport ORDER BY TransactionCode DESC"
        Try
            con.Open()
            Dim reader As SqlDataReader = cmd.ExecuteReader(CommandBehavior.SingleRow)
            If (reader.HasRows = True) Then
                While reader.Read()
                    GetCode = (reader.GetString(reader.GetOrdinal("TransactionCode")))
                End While
            End If
            reader.Close()
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            con.Close()
        End Try
        If (GetCode = "0") Then
            TextBoxTcode.Text = "TC0001"
        ElseIf (GetCode <> "0") Then
            Dim TotalCodeWithoutLabel As String = GetCode.Count - 2
            Dim OldNum As String = GetCode.Substring(GetCode.Length - TotalCodeWithoutLabel)
            TextBoxTcode.Text = "TC" + Format(OldNum + 1, "0000").ToString
        End If
        TCodeBTN.Visible = False
        UpdateStatusBTN.Enabled = True
        TextBoxTcode.Font = New Font(TextBoxTcode.Font.FontFamily, TextBoxTcode.Font.Size + 14, TextBoxTcode.Font.Style)
    End Sub


End Class