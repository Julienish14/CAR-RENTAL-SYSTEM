﻿Imports System.Data.SqlClient
Imports System.IO
Public Class AdminCars
    Dim carstatus As Boolean
    Dim table As New DataTable()
    Dim cmd As New SqlCommand
    Dim connection As New SqlConnection("Server = DESKTOP-N7870M5; Database = CAR RENTING SYSTEM DB; Integrated Security = true")

    Sub filterrecord(ByVal search As String)
        Dim query As String = "SELECT * FROM Carinformation"
        cmd = New SqlCommand(query, connection)
        Dim da = New SqlDataAdapter(cmd)
        Dim dt As New DataTable
        da.Fill(dt)
        DataGridView1.DataSource = dt

    End Sub

    Private Sub uploadCaPicBTN_Click(sender As Object, e As EventArgs) Handles uploadCaPicBTN.Click
        Try
            With OpenFileDialog1
                .Filter = ("Images |*.png; *.bmp; *.jpg;*.jpeg; *.gif;*.icon;")
                .FilterIndex = 8
            End With
            OpenFileDialog1.FileName = ""
            If OpenFileDialog1.ShowDialog() = DialogResult.OK Then
                PictureBox1.Image = Image.FromFile(OpenFileDialog1.FileName)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString())
        End Try
    End Sub

    ',,,,,,,,,,,,SAVE NEW CAR CODE,,,,,,,,,,,,,

    Private Sub AddCarBtn_Click(sender As Object, e As EventArgs) Handles AddCarSAVEBtn.Click

        If PictureBox1.Image Is Nothing Or TextBox1.Text = String.Empty Or TextBox2.Text = String.Empty Or TextBox3.Text = String.Empty Or TextBox4.Text = String.Empty Or TextBox5.Text = String.Empty Or TextBox6.Text = String.Empty Then
            MsgBox("Please!! UPLOAD CAR PICTURE AND FILL ALL INFORMATION ABOUT IT. ", MsgBoxStyle.Critical, "ERROR")
            PictureBox1.Focus()
            TextBox1.Focus()
        ElseIf RadioButton1.Checked = False And RadioButton2.Checked = False Then
            MsgBox("CHECK FOR CAR TRANSFORMATION", MsgBoxStyle.Critical, "FILL INFORMATION")
            RadioButton1.Focus()
            RadioButton2.Focus()
        ElseIf RadioButton3.Checked = False And RadioButton5CarstatusSAVE.Checked = False Then
            MsgBox("CHECK FOR STATUS", MsgBoxStyle.Critical, "FILL INFORMATION")
            RadioButton3.Focus()
            RadioButton5CarstatusSAVE.Focus()

        Else


            Dim cartrans As String = ""
            If RadioButton1.Checked = True Then
                cartrans = "Manual"
            Else
                cartrans = "Automatic"
            End If


            Dim command As New SqlCommand("insert into Carinformation (PlateNumber,Manufacture,Model,Color,YearOfMaker,PricePerDay,Image,DateAdmitted,CarTransmission,CarStatus)
values (@PlateNumber,@Manufacture,@Model,@Color,@YearOfMaker,@PricePerDay,@Image,@DateAdmitted,@CarTransmission,@CarStatus)", connection)



            Dim ms As New MemoryStream

            PictureBox1.Image.Save(ms, PictureBox1.Image.RawFormat)
            command.Parameters.Add("@PlateNumber", SqlDbType.VarChar).Value = TextBox1.Text
            command.Parameters.Add("@Manufacture", SqlDbType.VarChar).Value = TextBox2.Text
            command.Parameters.Add("@Model", SqlDbType.VarChar).Value = TextBox3.Text
            command.Parameters.Add("@Color", SqlDbType.VarChar).Value = TextBox4.Text
            command.Parameters.Add("@YearOfMaker", SqlDbType.VarChar).Value = TextBox5.Text
            command.Parameters.Add("@PricePerDay", SqlDbType.VarChar).Value = TextBox6.Text
            command.Parameters.Add("@Image", SqlDbType.Image).Value = ms.ToArray()
            command.Parameters.Add("@DateAdmitted", SqlDbType.Date).Value = DateTimePicker1.Value
            command.Parameters.Add("@CarTransmission", SqlDbType.VarChar).Value = cartrans
            command.Parameters.Add("@CarStatus", SqlDbType.VarChar).Value = carstatus
            connection.Open()

            If command.ExecuteNonQuery() = 1 Then
                MessageBox.Show("   CAR  " + TextBox2.Text + "  With  Plate  Number  " + TextBox1.Text + "  is ADDED IN SYSTEM")
                RadioButton1.Checked = False
                RadioButton2.Checked = False
                RadioButton5CarstatusSAVE.Checked = False
                RadioButton3.Checked = False
                filterrecord("")
                TextBox1.Clear()
                TextBox2.Clear()
                TextBox3.Clear()
                TextBox4.Clear()
                TextBox4.Clear()
                TextBox5.Clear()
                TextBox6.Clear()
            Else
                MessageBox.Show("Not inserted")
            End If

            connection.Close()

        End If


    End Sub

    Private Sub AdminCars_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'CAR_RENTING_SYSTEM_DBDataSet10.Carinformation' table. You can move, or remove it, as needed.
        Me.CarinformationTableAdapter.Fill(Me.CAR_RENTING_SYSTEM_DBDataSet10.Carinformation)
        filterrecord("")


    End Sub
    Private Sub DeletcarBTN_Click(sender As Object, e As EventArgs) Handles DeletcarBTN.Click
        Dim com As New SqlCommand("delete from Carinformation WHERE PlateNumber=@PlateNumber", connection)
        com.Parameters.Add("@PlateNumber", SqlDbType.VarChar).Value = TextBox1.Text

        Dim adapter As New SqlDataAdapter(com)
        adapter.Fill(table)
        If table.Rows.Count() <= 0 Then
            MsgBox("ARE YOU SURE YOU WANT TO DELETE CAR   " + TextBox3.Text + "   with Plate Number   " + TextBox1.Text, MsgBoxStyle.YesNo)
            filterrecord("")
            TextBox1.Clear()
            TextBox2.Clear()
            TextBox3.Clear()
            TextBox4.Clear()
            TextBox5.Clear()
            TextBox6.Clear()
        Else
            MessageBox.Show("FAIL TO DELETE A CAR")
        End If

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles ADDUPDATEBTN.Click
        Dim updateQuery As String = "Update Carinformation Set CarStatus = '" & RadioButton3.Checked & "' WHERE PlateNumber = '" & TextBox1.Text & "' "
        ExecuteQuery(updateQuery)
        MsgBox("CAR   " + TextBox3.Text + "  with  Plate  Number  " + TextBox1.Text + "                    
               IS ON THE LIST OF AVAILABLE CAR NOW", MsgBoxStyle.Information)
        filterrecord("")
    End Sub
    Public Sub ExecuteQuery(Query As String)
        Dim command As New SqlCommand(Query, connection)
        connection.Open()
        command.ExecuteNonQuery()
        connection.Close()

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles AddnewCarBTN.Click
        GroupBox8.BackColor = Color.Transparent

        ADDUPDATEBTN.BackColor = Color.Transparent
        ADDUPDATEBTN.ForeColor = Color.Black
        ADDUPDATEBTN.Enabled = False
        AddnewCarBTN.Visible = False
        uploadCaPicBTN.Visible = True
        AddCarSAVEBtn.Visible = True
        DeletcarBTN.Visible = False
        RadioButton4UPDATE.Enabled = False
        RadioButton1.Enabled = True
        RadioButton2.Enabled = True
        RadioButton3.Enabled = True
        RadioButton6UPDATEUnvailable.Enabled = False
        RadioButton5CarstatusSAVE.Enabled = False

        TextBox1.Clear()
        TextBox2.Clear()
        TextBox3.Clear()
        TextBox4.Clear()
        TextBox5.Clear()
        TextBox6.Clear()

    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        Dim index As Integer
        index = DataGridView1.CurrentRow.Index

        Me.TextBox1.Text = DataGridView1.Item(0, index).Value
        Me.TextBox2.Text = DataGridView1.Item(1, index).Value
        Me.TextBox3.Text = DataGridView1.Item(2, index).Value
        Me.TextBox4.Text = DataGridView1.Item(3, index).Value
        Me.TextBox5.Text = DataGridView1.Item(4, index).Value
        Me.TextBox6.Text = DataGridView1.Item(5, index).Value


        DeletcarBTN.Visible = True
        GroupBox8.BackColor = Color.Black
        ADDUPDATEBTN.BackColor = Color.White
        ADDUPDATEBTN.ForeColor = Color.Black
        ADDUPDATEBTN.Enabled = True
        RadioButton4UPDATE.Enabled = False
        RadioButton1.Enabled = False
        RadioButton2.Enabled = False
        RadioButton3.Enabled = False
        RadioButton5CarstatusSAVE.Enabled = False
        RadioButton6UPDATEUnvailable.Enabled = True
        RadioButton4UPDATE.Enabled = False
        uploadCaPicBTN.Visible = False
        AddCarSAVEBtn.Visible = False
        AddnewCarBTN.Visible = True
        TextBox7.Visible = True

    End Sub

    Private Sub GroupBox1_Enter(sender As Object, e As EventArgs) Handles GroupBox1.Enter

    End Sub
End Class