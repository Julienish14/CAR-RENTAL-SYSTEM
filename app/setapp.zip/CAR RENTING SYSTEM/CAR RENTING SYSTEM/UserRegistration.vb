﻿Imports System.Text.RegularExpressions
Imports System.Data.SqlClient
Imports System.ComponentModel

Public Class UserRegistration
    Dim connection As New SqlConnection("Server = DESKTOP-N7870M5; Database = CAR RENTING SYSTEM DB; Integrated Security = true")

    Private Sub submitBtn_Click_1(sender As Object, e As EventArgs) Handles submitBtn.Click
        Dim command As New SqlCommand("insert into Userinformation (Firstname,Surname,DateOfBirth,Username,Password,Contact_No,Email,Address,DateOfJoining,Driver_LicenceNo,IDNumber) values(@Firstname,@Surname,@DateOfBirth,@Username,@Password,@Contact_No,@Email,@Address,@DateOfJoining,@Driver_LicenceNo,@IDNumber)", connection)

        If TextBox1.Text = String.Empty Or TextBox2.Text = String.Empty Or TextBox3.Text = String.Empty Or TextBox4.Text = String.Empty Or TextBox5.Text = String.Empty Or
            TextBox6.Text = String.Empty Or TextBox7.Text = String.Empty And TextBox8.Text = String.Empty Then
            MsgBox("INFORMATION TO CREATE ACCOUNT IS INCOMPLETE  ", MsgBoxStyle.Information, "FILL INFORMATION FORM ")
        Else

            command.Parameters.Add("@Firstname", SqlDbType.VarChar).Value = TextBox1.Text
            command.Parameters.Add("@Surname", SqlDbType.VarChar).Value = TextBox2.Text
            command.Parameters.Add("@DateOfBirth", SqlDbType.Date).Value = DateTimePicker1.Value
            command.Parameters.Add("@Username", SqlDbType.VarChar).Value = TextBox3.Text
            command.Parameters.Add("@Password", SqlDbType.VarChar).Value = TextBox4.Text
            command.Parameters.Add("@Contact_No", SqlDbType.VarChar).Value = TextBox5.Text
            command.Parameters.Add("@Email", SqlDbType.VarChar).Value = TextBox6.Text
            command.Parameters.Add("@Address", SqlDbType.VarChar).Value = TextBox7.Text
            command.Parameters.Add("@DateOfJoining", SqlDbType.Date).Value = DateTimePicker2.Value
            command.Parameters.Add("@Driver_LicenceNo", SqlDbType.VarChar).Value = TextBox8.Text
            command.Parameters.Add("@IDNumber", SqlDbType.VarChar).Value = TextBoxIDNumber.Text

            End If
            connection.Open()

            If command.ExecuteNonQuery() = 1 Then
                MsgBox("Hi!!  " + TextBox1.Text & "  " + TextBox2.Text & "  YOUR ACCOUNT HAS BEEN SUCCESSFULLY CREATED.       YOUR   REGISTRATION  NUMBER IS  :   " + TextBoxIDNumber.Text, MsgBoxStyle.Information, "CONGRATULATION")
                Me.Hide()
                userLogin.Show()
            Else
                MessageBox.Show("Your Registration is Fail")
                MessageBox.Show("Try Again!!!")
            End If

            connection.Close()

    End Sub

    Private Sub cancelBtn_Click_1(sender As Object, e As EventArgs) Handles cancelBtn.Click
        Close()
        Me.Hide()
        loginboth.Show()
    End Sub

    Private Sub UserRegistration_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.Text = "USER SIGNUP"
        Me.MinimizeBox = False
    End Sub

    Private Sub GetIDNumberBTN_Click(sender As Object, e As EventArgs) Handles GetIDNumberBTN.Click


        Dim email As String
        email = "^([0-9a-zA-z]([-\.\w]*[0-9a-zA-Z])*@([0-9a-zA-z][-\w]*[0-9a-zA-Z]\.)+[a-zA-Z]{2,9})$"
        If Not Regex.IsMatch(TextBox6.Text, email) Then
            ErrorProvider1.SetError(TextBox6, " Email not Valid")
            TextBox6.Focus()
            MsgBox("Enter Valid Email", MsgBoxStyle.Information, "Error")
        Else
            ErrorProvider1.SetError(TextBox6, "")
            submitBtn.Enabled = True
            cancelBtn.Enabled = True
            TextBoxIDNumber.BackColor = Color.DarkSlateGray
            TextBoxIDNumber.ForeColor = Color.Black
            TextBoxIDNumber.Font = New Font(TextBoxIDNumber.Font.FontFamily, TextBoxIDNumber.Font.Size + 14, TextBoxIDNumber.Font.Style)
            GetIDNumberBTN.Visible = False


            Dim GetCode As String = "0"
            Dim cmd As New SqlCommand
            cmd = New SqlCommand
            cmd.Connection = connection
            cmd.CommandText = "SELECT TOP(1) * FROM Userinformation ORDER BY IDNumber DESC"
            Try
                connection.Open()
                Dim reader As SqlDataReader = cmd.ExecuteReader(CommandBehavior.SingleRow)
                If (reader.HasRows = True) Then
                    While reader.Read()
                        GetCode = (reader.GetString(reader.GetOrdinal("IDNumber")))
                    End While
                End If
                reader.Close()
            Catch ex As Exception
                MsgBox(ex.Message)
            Finally
                connection.Close()
            End Try
            If (GetCode = "0") Then
                TextBoxIDNumber.Text = "A001"
            ElseIf (GetCode <> "0") Then
                Dim TotalCodeWithoutLabel As String = GetCode.Count - 1
                Dim OldNum As String = GetCode.Substring(GetCode.Length - TotalCodeWithoutLabel)
                TextBoxIDNumber.Text = "A" + Format(OldNum + 1, "000").ToString
            End If
        End If
    End Sub

    Private Sub ShowPassword_Click(sender As Object, e As EventArgs) Handles ShowPassword.Click
        If TextBox4.UseSystemPasswordChar = True Then
            TextBox4.UseSystemPasswordChar = False
        Else
            TextBox4.UseSystemPasswordChar = True
        End If
    End Sub

    Private Sub GroupBox1_Enter(sender As Object, e As EventArgs) Handles GroupBox1.Enter
        TextBox4.UseSystemPasswordChar = True
    End Sub




End Class