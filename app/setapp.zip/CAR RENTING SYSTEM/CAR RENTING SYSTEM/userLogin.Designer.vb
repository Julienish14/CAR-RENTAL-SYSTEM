﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class userLogin
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(userLogin))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.LoginUsernameBTN = New System.Windows.Forms.Button()
        Me.CancelUsernameBTN = New System.Windows.Forms.Button()
        Me.createAccountBTN = New System.Windows.Forms.Button()
        Me.ShowPassword = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Imprint MT Shadow", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(110, 97)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(102, 23)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Username"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Imprint MT Shadow", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(110, 150)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(95, 23)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Password"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Black
        Me.Label3.Font = New System.Drawing.Font("Modern No. 20", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.Azure
        Me.Label3.Location = New System.Drawing.Point(6, 317)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(182, 17)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "If is your first time here"
        '
        'TextBox1
        '
        Me.TextBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox1.Location = New System.Drawing.Point(64, 123)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(176, 24)
        Me.TextBox1.TabIndex = 3
        Me.TextBox1.Tag = "Enter Your Username"
        '
        'TextBox2
        '
        Me.TextBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox2.Location = New System.Drawing.Point(64, 176)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(176, 24)
        Me.TextBox2.TabIndex = 4
        Me.TextBox2.Tag = "Enter Your Password"
        '
        'LoginUsernameBTN
        '
        Me.LoginUsernameBTN.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.LoginUsernameBTN.Font = New System.Drawing.Font("Imprint MT Shadow", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LoginUsernameBTN.ForeColor = System.Drawing.Color.White
        Me.LoginUsernameBTN.Location = New System.Drawing.Point(64, 208)
        Me.LoginUsernameBTN.Name = "LoginUsernameBTN"
        Me.LoginUsernameBTN.Size = New System.Drawing.Size(176, 39)
        Me.LoginUsernameBTN.TabIndex = 5
        Me.LoginUsernameBTN.Text = "LOGIN"
        Me.LoginUsernameBTN.UseVisualStyleBackColor = True
        '
        'CancelUsernameBTN
        '
        Me.CancelUsernameBTN.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CancelUsernameBTN.Font = New System.Drawing.Font("Imprint MT Shadow", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CancelUsernameBTN.ForeColor = System.Drawing.Color.White
        Me.CancelUsernameBTN.Location = New System.Drawing.Point(64, 262)
        Me.CancelUsernameBTN.Name = "CancelUsernameBTN"
        Me.CancelUsernameBTN.Size = New System.Drawing.Size(176, 34)
        Me.CancelUsernameBTN.TabIndex = 6
        Me.CancelUsernameBTN.Text = "CANCEL"
        Me.CancelUsernameBTN.UseVisualStyleBackColor = True
        '
        'createAccountBTN
        '
        Me.createAccountBTN.BackColor = System.Drawing.Color.Black
        Me.createAccountBTN.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.createAccountBTN.Font = New System.Drawing.Font("Imprint MT Shadow", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.createAccountBTN.ForeColor = System.Drawing.Color.White
        Me.createAccountBTN.Location = New System.Drawing.Point(147, 337)
        Me.createAccountBTN.Name = "createAccountBTN"
        Me.createAccountBTN.Size = New System.Drawing.Size(156, 29)
        Me.createAccountBTN.TabIndex = 7
        Me.createAccountBTN.Text = "Create Account"
        Me.createAccountBTN.UseVisualStyleBackColor = False
        '
        'ShowPassword
        '
        Me.ShowPassword.BackgroundImage = Global.CAR_RENTING_SYSTEM.My.Resources.Resources.Show
        Me.ShowPassword.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ShowPassword.Location = New System.Drawing.Point(212, 176)
        Me.ShowPassword.Name = "ShowPassword"
        Me.ShowPassword.Size = New System.Drawing.Size(28, 23)
        Me.ShowPassword.TabIndex = 8
        Me.ShowPassword.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox1.Controls.Add(Me.ShowPassword)
        Me.GroupBox1.Controls.Add(Me.createAccountBTN)
        Me.GroupBox1.Controls.Add(Me.CancelUsernameBTN)
        Me.GroupBox1.Controls.Add(Me.LoginUsernameBTN)
        Me.GroupBox1.Controls.Add(Me.TextBox2)
        Me.GroupBox1.Controls.Add(Me.TextBox1)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Location = New System.Drawing.Point(337, 22)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(309, 371)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        '
        'userLogin
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.CAR_RENTING_SYSTEM.My.Resources.Resources.ford_Mustang
        Me.ClientSize = New System.Drawing.Size(959, 541)
        Me.Controls.Add(Me.GroupBox1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "userLogin"
        Me.Text = "userLogin"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents LoginUsernameBTN As Button
    Friend WithEvents CancelUsernameBTN As Button
    Friend WithEvents createAccountBTN As Button
    Friend WithEvents ShowPassword As Button
    Friend WithEvents GroupBox1 As GroupBox
End Class
