﻿Imports System.Data.SqlClient
Public Class CarReport
    Dim cmd As New SqlCommand
    Dim con As New SqlConnection("Server = DESKTOP-N7870M5; Database = CAR RENTING SYSTEM DB; Integrated Security = true")
    Private Sub CarReport_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'CAR_RENTING_SYSTEM_DBDataSet13.CarReport' table. You can move, or remove it, as needed.
        Me.CarReportTableAdapter.Fill(Me.CAR_RENTING_SYSTEM_DBDataSet13.CarReport)

    End Sub
    Sub Loaddata(ByVal search As String)
        Dim query As String = "SELECT * FROM CarReport"
        cmd = New SqlCommand(query, con)
        Dim da = New SqlDataAdapter(cmd)
        Dim dt As New DataTable
        da.Fill(dt)
        DataGridView1.DataSource = dt
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim com As New SqlCommand("delete from CarReport where  TransactionCode=@TransactionCode", con)
        Dim table As New DataTable
        Dim adapter As New SqlDataAdapter(com)
        com.Parameters.Add("@TransactionCode", SqlDbType.VarChar).Value = TextBoxTCode.Text

        adapter.Fill(table)
        If table.Rows.Count() <= 0 Then
            MessageBox.Show("TRANSACTION INFORMATION NUMBER  " + TextBoxTCode.Text + " DELETED ")
            Loaddata(" ")

        Else
            MessageBox.Show("INFORMATION NOT DELETED")
        End If


    End Sub



    Private Sub DataGridView1_CellContentClick_1(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        Try
            Dim i As Integer
            i = DataGridView1.CurrentRow.Index
            Me.TextBoxIDNumber.Text = DataGridView1.Item(0, i).Value
            Me.TextBoxFirstname.Text = DataGridView1.Item(1, i).Value
            Me.TextBoxSurname.Text = DataGridView1.Item(2, i).Value
            Me.TextBoxContactNo.Text = DataGridView1.Item(3, i).Value
            Me.TextBoxPlateNumber.Text = DataGridView1.Item(5, i).Value
            Me.TextBoxManufucture.Text = DataGridView1.Item(6, i).Value
            Me.TextBoxModel.Text = DataGridView1.Item(7, i).Value
            Me.TextBoxPricePerDay.Text = DataGridView1.Item(8, i).Value
            Me.TextBoxRentWithDriver.Text = DataGridView1.Item(9, i).Value
            Me.TextBoxNumberOfDay.Text = DataGridView1.Item(10, i).Value
            Me.TextBoxTotalPrice.Text = DataGridView1.Item(11, i).Value
            Me.TextBoxDayofRent.Text = DataGridView1.Item(12, i).Value
            Me.TextBoxTCode.Text = DataGridView1.Item(4, i).Value
            Me.TextBoxDatetoretun.Text = DataGridView1.Item(13, i).Value

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
End Class