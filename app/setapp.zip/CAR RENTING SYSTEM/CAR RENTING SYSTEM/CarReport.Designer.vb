﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CarReport
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(CarReport))
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.IDNumberDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.FirstnameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SurnameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ContactNoDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TransactionCodeDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PlateNumberDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ManufactureDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ModelDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PricePerDayDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.RentWithDriveDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.NumberOfDaysDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TotalPriceDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DateOfRentingDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DateRetunCarDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CarReportBindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.CARRENTINGSYSTEMDBDataSet13BindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.CAR_RENTING_SYSTEM_DBDataSet13 = New CAR_RENTING_SYSTEM.CAR_RENTING_SYSTEM_DBDataSet13()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.TextBoxDatetoretun = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.TextBoxTCode = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.TextBoxManufucture = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.TextBoxModel = New System.Windows.Forms.TextBox()
        Me.TextBoxPricePerDay = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.TextBoxDayofRent = New System.Windows.Forms.TextBox()
        Me.TextBoxRentWithDriver = New System.Windows.Forms.TextBox()
        Me.TextBoxTotalPrice = New System.Windows.Forms.TextBox()
        Me.TextBoxPlateNumber = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.TextBoxNumberOfDay = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.TextBoxContactNo = New System.Windows.Forms.TextBox()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.TextBoxIDNumber = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TextBoxFirstname = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TextBoxSurname = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.CarReportBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.CarReportTableAdapter = New CAR_RENTING_SYSTEM.CAR_RENTING_SYSTEM_DBDataSet13TableAdapters.CarReportTableAdapter()
        Me.GroupBox3.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CarReportBindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CARRENTINGSYSTEMDBDataSet13BindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CAR_RENTING_SYSTEM_DBDataSet13, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.CarReportBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox3
        '
        Me.GroupBox3.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.GroupBox3.Controls.Add(Me.DataGridView1)
        Me.GroupBox3.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox3.Location = New System.Drawing.Point(32, 411)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(1309, 214)
        Me.GroupBox3.TabIndex = 3
        Me.GroupBox3.TabStop = False
        '
        'DataGridView1
        '
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.IDNumberDataGridViewTextBoxColumn, Me.FirstnameDataGridViewTextBoxColumn, Me.SurnameDataGridViewTextBoxColumn, Me.ContactNoDataGridViewTextBoxColumn, Me.TransactionCodeDataGridViewTextBoxColumn, Me.PlateNumberDataGridViewTextBoxColumn, Me.ManufactureDataGridViewTextBoxColumn, Me.ModelDataGridViewTextBoxColumn, Me.PricePerDayDataGridViewTextBoxColumn, Me.RentWithDriveDataGridViewTextBoxColumn, Me.NumberOfDaysDataGridViewTextBoxColumn, Me.TotalPriceDataGridViewTextBoxColumn, Me.DateOfRentingDataGridViewTextBoxColumn, Me.DateRetunCarDataGridViewTextBoxColumn})
        Me.DataGridView1.DataSource = Me.CarReportBindingSource1
        Me.DataGridView1.Location = New System.Drawing.Point(6, 14)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(1293, 185)
        Me.DataGridView1.TabIndex = 0
        '
        'IDNumberDataGridViewTextBoxColumn
        '
        Me.IDNumberDataGridViewTextBoxColumn.DataPropertyName = "IDNumber"
        Me.IDNumberDataGridViewTextBoxColumn.HeaderText = "IDNumber"
        Me.IDNumberDataGridViewTextBoxColumn.Name = "IDNumberDataGridViewTextBoxColumn"
        '
        'FirstnameDataGridViewTextBoxColumn
        '
        Me.FirstnameDataGridViewTextBoxColumn.DataPropertyName = "Firstname"
        Me.FirstnameDataGridViewTextBoxColumn.HeaderText = "Firstname"
        Me.FirstnameDataGridViewTextBoxColumn.Name = "FirstnameDataGridViewTextBoxColumn"
        Me.FirstnameDataGridViewTextBoxColumn.Visible = False
        '
        'SurnameDataGridViewTextBoxColumn
        '
        Me.SurnameDataGridViewTextBoxColumn.DataPropertyName = "Surname"
        Me.SurnameDataGridViewTextBoxColumn.HeaderText = "Surname"
        Me.SurnameDataGridViewTextBoxColumn.Name = "SurnameDataGridViewTextBoxColumn"
        Me.SurnameDataGridViewTextBoxColumn.Visible = False
        '
        'ContactNoDataGridViewTextBoxColumn
        '
        Me.ContactNoDataGridViewTextBoxColumn.DataPropertyName = "ContactNo"
        Me.ContactNoDataGridViewTextBoxColumn.HeaderText = "ContactNo"
        Me.ContactNoDataGridViewTextBoxColumn.Name = "ContactNoDataGridViewTextBoxColumn"
        Me.ContactNoDataGridViewTextBoxColumn.Visible = False
        '
        'TransactionCodeDataGridViewTextBoxColumn
        '
        Me.TransactionCodeDataGridViewTextBoxColumn.DataPropertyName = "TransactionCode"
        Me.TransactionCodeDataGridViewTextBoxColumn.HeaderText = "TransactionCode"
        Me.TransactionCodeDataGridViewTextBoxColumn.Name = "TransactionCodeDataGridViewTextBoxColumn"
        Me.TransactionCodeDataGridViewTextBoxColumn.Width = 140
        '
        'PlateNumberDataGridViewTextBoxColumn
        '
        Me.PlateNumberDataGridViewTextBoxColumn.DataPropertyName = "PlateNumber"
        Me.PlateNumberDataGridViewTextBoxColumn.HeaderText = "PlateNumber"
        Me.PlateNumberDataGridViewTextBoxColumn.Name = "PlateNumberDataGridViewTextBoxColumn"
        Me.PlateNumberDataGridViewTextBoxColumn.Width = 130
        '
        'ManufactureDataGridViewTextBoxColumn
        '
        Me.ManufactureDataGridViewTextBoxColumn.DataPropertyName = "Manufacture"
        Me.ManufactureDataGridViewTextBoxColumn.HeaderText = "Manufacture"
        Me.ManufactureDataGridViewTextBoxColumn.Name = "ManufactureDataGridViewTextBoxColumn"
        Me.ManufactureDataGridViewTextBoxColumn.Visible = False
        '
        'ModelDataGridViewTextBoxColumn
        '
        Me.ModelDataGridViewTextBoxColumn.DataPropertyName = "Model"
        Me.ModelDataGridViewTextBoxColumn.HeaderText = "Model"
        Me.ModelDataGridViewTextBoxColumn.Name = "ModelDataGridViewTextBoxColumn"
        Me.ModelDataGridViewTextBoxColumn.Width = 130
        '
        'PricePerDayDataGridViewTextBoxColumn
        '
        Me.PricePerDayDataGridViewTextBoxColumn.DataPropertyName = "PricePerDay"
        Me.PricePerDayDataGridViewTextBoxColumn.HeaderText = "PricePerDay"
        Me.PricePerDayDataGridViewTextBoxColumn.Name = "PricePerDayDataGridViewTextBoxColumn"
        Me.PricePerDayDataGridViewTextBoxColumn.Width = 120
        '
        'RentWithDriveDataGridViewTextBoxColumn
        '
        Me.RentWithDriveDataGridViewTextBoxColumn.DataPropertyName = "RentWithDrive"
        Me.RentWithDriveDataGridViewTextBoxColumn.HeaderText = "RentWithDrive"
        Me.RentWithDriveDataGridViewTextBoxColumn.Name = "RentWithDriveDataGridViewTextBoxColumn"
        Me.RentWithDriveDataGridViewTextBoxColumn.Width = 125
        '
        'NumberOfDaysDataGridViewTextBoxColumn
        '
        Me.NumberOfDaysDataGridViewTextBoxColumn.DataPropertyName = "NumberOfDays"
        Me.NumberOfDaysDataGridViewTextBoxColumn.HeaderText = "NumberOfDays"
        Me.NumberOfDaysDataGridViewTextBoxColumn.Name = "NumberOfDaysDataGridViewTextBoxColumn"
        Me.NumberOfDaysDataGridViewTextBoxColumn.Width = 130
        '
        'TotalPriceDataGridViewTextBoxColumn
        '
        Me.TotalPriceDataGridViewTextBoxColumn.DataPropertyName = "TotalPrice"
        Me.TotalPriceDataGridViewTextBoxColumn.HeaderText = "TotalPrice"
        Me.TotalPriceDataGridViewTextBoxColumn.Name = "TotalPriceDataGridViewTextBoxColumn"
        Me.TotalPriceDataGridViewTextBoxColumn.Width = 120
        '
        'DateOfRentingDataGridViewTextBoxColumn
        '
        Me.DateOfRentingDataGridViewTextBoxColumn.DataPropertyName = "DateOfRenting"
        Me.DateOfRentingDataGridViewTextBoxColumn.HeaderText = "DateOfRenting"
        Me.DateOfRentingDataGridViewTextBoxColumn.Name = "DateOfRentingDataGridViewTextBoxColumn"
        Me.DateOfRentingDataGridViewTextBoxColumn.Width = 130
        '
        'DateRetunCarDataGridViewTextBoxColumn
        '
        Me.DateRetunCarDataGridViewTextBoxColumn.DataPropertyName = "DateRetunCar"
        Me.DateRetunCarDataGridViewTextBoxColumn.HeaderText = "DateRetunCar"
        Me.DateRetunCarDataGridViewTextBoxColumn.Name = "DateRetunCarDataGridViewTextBoxColumn"
        Me.DateRetunCarDataGridViewTextBoxColumn.Width = 130
        '
        'CarReportBindingSource1
        '
        Me.CarReportBindingSource1.DataMember = "CarReport"
        Me.CarReportBindingSource1.DataSource = Me.CARRENTINGSYSTEMDBDataSet13BindingSource
        '
        'CARRENTINGSYSTEMDBDataSet13BindingSource
        '
        Me.CARRENTINGSYSTEMDBDataSet13BindingSource.DataSource = Me.CAR_RENTING_SYSTEM_DBDataSet13
        Me.CARRENTINGSYSTEMDBDataSet13BindingSource.Position = 0
        '
        'CAR_RENTING_SYSTEM_DBDataSet13
        '
        Me.CAR_RENTING_SYSTEM_DBDataSet13.DataSetName = "CAR_RENTING_SYSTEM_DBDataSet13"
        Me.CAR_RENTING_SYSTEM_DBDataSet13.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox1.Controls.Add(Me.GroupBox5)
        Me.GroupBox1.Controls.Add(Me.GroupBox2)
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.ForeColor = System.Drawing.Color.White
        Me.GroupBox1.Location = New System.Drawing.Point(206, 176)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(1039, 229)
        Me.GroupBox1.TabIndex = 4
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "INFORMATION FOR RENT"
        '
        'GroupBox5
        '
        Me.GroupBox5.BackColor = System.Drawing.Color.Black
        Me.GroupBox5.Controls.Add(Me.TextBoxDatetoretun)
        Me.GroupBox5.Controls.Add(Me.Label14)
        Me.GroupBox5.Controls.Add(Me.Label9)
        Me.GroupBox5.Controls.Add(Me.TextBoxTCode)
        Me.GroupBox5.Controls.Add(Me.Label8)
        Me.GroupBox5.Controls.Add(Me.TextBoxManufucture)
        Me.GroupBox5.Controls.Add(Me.Label15)
        Me.GroupBox5.Controls.Add(Me.TextBoxModel)
        Me.GroupBox5.Controls.Add(Me.TextBoxPricePerDay)
        Me.GroupBox5.Controls.Add(Me.Label11)
        Me.GroupBox5.Controls.Add(Me.TextBoxDayofRent)
        Me.GroupBox5.Controls.Add(Me.TextBoxRentWithDriver)
        Me.GroupBox5.Controls.Add(Me.TextBoxTotalPrice)
        Me.GroupBox5.Controls.Add(Me.TextBoxPlateNumber)
        Me.GroupBox5.Controls.Add(Me.Label12)
        Me.GroupBox5.Controls.Add(Me.Label13)
        Me.GroupBox5.Controls.Add(Me.TextBoxNumberOfDay)
        Me.GroupBox5.Controls.Add(Me.Label7)
        Me.GroupBox5.Controls.Add(Me.Label6)
        Me.GroupBox5.Controls.Add(Me.Label5)
        Me.GroupBox5.Font = New System.Drawing.Font("Rockwell", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox5.ForeColor = System.Drawing.Color.White
        Me.GroupBox5.Location = New System.Drawing.Point(310, 20)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(723, 196)
        Me.GroupBox5.TabIndex = 6
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "CAR INFO"
        '
        'TextBoxDatetoretun
        '
        Me.TextBoxDatetoretun.Location = New System.Drawing.Point(574, 158)
        Me.TextBoxDatetoretun.Name = "TextBoxDatetoretun"
        Me.TextBoxDatetoretun.ReadOnly = True
        Me.TextBoxDatetoretun.Size = New System.Drawing.Size(132, 25)
        Me.TextBoxDatetoretun.TabIndex = 72
        Me.TextBoxDatetoretun.TabStop = False
        Me.TextBoxDatetoretun.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Trebuchet MS", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(395, 159)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(162, 24)
        Me.Label14.TabIndex = 71
        Me.Label14.Text = "Date to Return  :"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Trebuchet MS", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(6, 35)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(170, 24)
        Me.Label9.TabIndex = 70
        Me.Label9.Text = "TransactionCode :"
        '
        'TextBoxTCode
        '
        Me.TextBoxTCode.Location = New System.Drawing.Point(182, 37)
        Me.TextBoxTCode.Name = "TextBoxTCode"
        Me.TextBoxTCode.Size = New System.Drawing.Size(188, 25)
        Me.TextBoxTCode.TabIndex = 69
        Me.TextBoxTCode.TabStop = False
        Me.TextBoxTCode.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Trebuchet MS", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(395, 98)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(120, 24)
        Me.Label8.TabIndex = 68
        Me.Label8.Text = "Total Price :"
        '
        'TextBoxManufucture
        '
        Me.TextBoxManufucture.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxManufucture.Location = New System.Drawing.Point(182, 101)
        Me.TextBoxManufucture.Name = "TextBoxManufucture"
        Me.TextBoxManufucture.ReadOnly = True
        Me.TextBoxManufucture.Size = New System.Drawing.Size(188, 22)
        Me.TextBoxManufucture.TabIndex = 55
        Me.TextBoxManufucture.TabStop = False
        Me.TextBoxManufucture.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Trebuchet MS", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(395, 130)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(163, 24)
        Me.Label15.TabIndex = 67
        Me.Label15.Text = "Date of Renting :"
        '
        'TextBoxModel
        '
        Me.TextBoxModel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxModel.Location = New System.Drawing.Point(182, 132)
        Me.TextBoxModel.Name = "TextBoxModel"
        Me.TextBoxModel.ReadOnly = True
        Me.TextBoxModel.Size = New System.Drawing.Size(188, 22)
        Me.TextBoxModel.TabIndex = 56
        Me.TextBoxModel.TabStop = False
        Me.TextBoxModel.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBoxPricePerDay
        '
        Me.TextBoxPricePerDay.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxPricePerDay.Location = New System.Drawing.Point(182, 162)
        Me.TextBoxPricePerDay.Name = "TextBoxPricePerDay"
        Me.TextBoxPricePerDay.ReadOnly = True
        Me.TextBoxPricePerDay.Size = New System.Drawing.Size(188, 22)
        Me.TextBoxPricePerDay.TabIndex = 57
        Me.TextBoxPricePerDay.TabStop = False
        Me.TextBoxPricePerDay.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Trebuchet MS", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(6, 156)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(142, 24)
        Me.Label11.TabIndex = 52
        Me.Label11.Text = "Price Per Day :"
        '
        'TextBoxDayofRent
        '
        Me.TextBoxDayofRent.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxDayofRent.Location = New System.Drawing.Point(574, 129)
        Me.TextBoxDayofRent.Name = "TextBoxDayofRent"
        Me.TextBoxDayofRent.ReadOnly = True
        Me.TextBoxDayofRent.Size = New System.Drawing.Size(132, 22)
        Me.TextBoxDayofRent.TabIndex = 64
        Me.TextBoxDayofRent.TabStop = False
        Me.TextBoxDayofRent.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBoxRentWithDriver
        '
        Me.TextBoxRentWithDriver.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxRentWithDriver.Location = New System.Drawing.Point(575, 33)
        Me.TextBoxRentWithDriver.Name = "TextBoxRentWithDriver"
        Me.TextBoxRentWithDriver.ReadOnly = True
        Me.TextBoxRentWithDriver.Size = New System.Drawing.Size(131, 22)
        Me.TextBoxRentWithDriver.TabIndex = 58
        Me.TextBoxRentWithDriver.TabStop = False
        Me.TextBoxRentWithDriver.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBoxTotalPrice
        '
        Me.TextBoxTotalPrice.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxTotalPrice.Location = New System.Drawing.Point(574, 99)
        Me.TextBoxTotalPrice.Name = "TextBoxTotalPrice"
        Me.TextBoxTotalPrice.ReadOnly = True
        Me.TextBoxTotalPrice.Size = New System.Drawing.Size(132, 22)
        Me.TextBoxTotalPrice.TabIndex = 63
        Me.TextBoxTotalPrice.TabStop = False
        Me.TextBoxTotalPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBoxPlateNumber
        '
        Me.TextBoxPlateNumber.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxPlateNumber.Location = New System.Drawing.Point(182, 70)
        Me.TextBoxPlateNumber.Margin = New System.Windows.Forms.Padding(1)
        Me.TextBoxPlateNumber.Name = "TextBoxPlateNumber"
        Me.TextBoxPlateNumber.ReadOnly = True
        Me.TextBoxPlateNumber.Size = New System.Drawing.Size(188, 22)
        Me.TextBoxPlateNumber.TabIndex = 54
        Me.TextBoxPlateNumber.TabStop = False
        Me.TextBoxPlateNumber.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Trebuchet MS", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(395, 31)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(174, 24)
        Me.Label12.TabIndex = 61
        Me.Label12.Text = "Rent with Driver :"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Trebuchet MS", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(395, 66)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(155, 24)
        Me.Label13.TabIndex = 62
        Me.Label13.Text = "Number of Day :"
        '
        'TextBoxNumberOfDay
        '
        Me.TextBoxNumberOfDay.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxNumberOfDay.Location = New System.Drawing.Point(576, 68)
        Me.TextBoxNumberOfDay.Name = "TextBoxNumberOfDay"
        Me.TextBoxNumberOfDay.ReadOnly = True
        Me.TextBoxNumberOfDay.Size = New System.Drawing.Size(132, 22)
        Me.TextBoxNumberOfDay.TabIndex = 60
        Me.TextBoxNumberOfDay.TabStop = False
        Me.TextBoxNumberOfDay.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Trebuchet MS", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(6, 126)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(76, 24)
        Me.Label7.TabIndex = 50
        Me.Label7.Text = "Model :"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Trebuchet MS", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(6, 66)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(145, 24)
        Me.Label6.TabIndex = 48
        Me.Label6.Text = "Plate Number :"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Trebuchet MS", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(6, 96)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(142, 24)
        Me.Label5.TabIndex = 49
        Me.Label5.Text = "Manufacturer :"
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.Black
        Me.GroupBox2.Controls.Add(Me.Label4)
        Me.GroupBox2.Controls.Add(Me.TextBoxContactNo)
        Me.GroupBox2.Controls.Add(Me.GroupBox4)
        Me.GroupBox2.Controls.Add(Me.TextBoxIDNumber)
        Me.GroupBox2.Controls.Add(Me.Label1)
        Me.GroupBox2.Controls.Add(Me.TextBoxFirstname)
        Me.GroupBox2.Controls.Add(Me.Label2)
        Me.GroupBox2.Controls.Add(Me.TextBoxSurname)
        Me.GroupBox2.Controls.Add(Me.Label3)
        Me.GroupBox2.Font = New System.Drawing.Font("Rockwell", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.ForeColor = System.Drawing.Color.White
        Me.GroupBox2.Location = New System.Drawing.Point(16, 71)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(288, 145)
        Me.GroupBox2.TabIndex = 68
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "CUSTOMER INFO"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Trebuchet MS", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(6, 115)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(110, 24)
        Me.Label4.TabIndex = 71
        Me.Label4.Text = "IDNumber :"
        '
        'TextBoxContactNo
        '
        Me.TextBoxContactNo.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxContactNo.Location = New System.Drawing.Point(123, 91)
        Me.TextBoxContactNo.Name = "TextBoxContactNo"
        Me.TextBoxContactNo.ReadOnly = True
        Me.TextBoxContactNo.Size = New System.Drawing.Size(159, 22)
        Me.TextBoxContactNo.TabIndex = 70
        Me.TextBoxContactNo.TabStop = False
        Me.TextBoxContactNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'GroupBox4
        '
        Me.GroupBox4.Location = New System.Drawing.Point(288, 72)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(529, 277)
        Me.GroupBox4.TabIndex = 69
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "GroupBox4"
        '
        'TextBoxIDNumber
        '
        Me.TextBoxIDNumber.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxIDNumber.Location = New System.Drawing.Point(123, 117)
        Me.TextBoxIDNumber.Name = "TextBoxIDNumber"
        Me.TextBoxIDNumber.ReadOnly = True
        Me.TextBoxIDNumber.Size = New System.Drawing.Size(159, 22)
        Me.TextBoxIDNumber.TabIndex = 19
        Me.TextBoxIDNumber.TabStop = False
        Me.TextBoxIDNumber.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Trebuchet MS", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(6, 31)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(112, 24)
        Me.Label1.TabIndex = 14
        Me.Label1.Text = "Firstname :"
        '
        'TextBoxFirstname
        '
        Me.TextBoxFirstname.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxFirstname.Location = New System.Drawing.Point(123, 34)
        Me.TextBoxFirstname.Name = "TextBoxFirstname"
        Me.TextBoxFirstname.ReadOnly = True
        Me.TextBoxFirstname.Size = New System.Drawing.Size(159, 22)
        Me.TextBoxFirstname.TabIndex = 15
        Me.TextBoxFirstname.TabStop = False
        Me.TextBoxFirstname.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Trebuchet MS", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(6, 60)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(100, 24)
        Me.Label2.TabIndex = 16
        Me.Label2.Text = "Surname :"
        '
        'TextBoxSurname
        '
        Me.TextBoxSurname.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxSurname.Location = New System.Drawing.Point(123, 63)
        Me.TextBoxSurname.Name = "TextBoxSurname"
        Me.TextBoxSurname.ReadOnly = True
        Me.TextBoxSurname.Size = New System.Drawing.Size(159, 22)
        Me.TextBoxSurname.TabIndex = 17
        Me.TextBoxSurname.TabStop = False
        Me.TextBoxSurname.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Trebuchet MS", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(6, 88)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(117, 24)
        Me.Label3.TabIndex = 18
        Me.Label3.Text = "ContactNo :"
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.Black
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button1.Font = New System.Drawing.Font("Algerian", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ForeColor = System.Drawing.Color.White
        Me.Button1.Location = New System.Drawing.Point(1037, 631)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(304, 49)
        Me.Button1.TabIndex = 5
        Me.Button1.Text = "DELETE INFORMATION"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.Transparent
        Me.Label10.Font = New System.Drawing.Font("Algerian", 72.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.White
        Me.Label10.Location = New System.Drawing.Point(380, 46)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(624, 106)
        Me.Label10.TabIndex = 69
        Me.Label10.Text = "CAR REPORT"
        '
        'CarReportBindingSource
        '
        Me.CarReportBindingSource.DataMember = "CarReport"
        Me.CarReportBindingSource.DataSource = Me.CAR_RENTING_SYSTEM_DBDataSet13
        '
        'CarReportTableAdapter
        '
        Me.CarReportTableAdapter.ClearBeforeFill = True
        '
        'CarReport
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.CAR_RENTING_SYSTEM.My.Resources.Resources.pic
        Me.ClientSize = New System.Drawing.Size(1370, 749)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.GroupBox3)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "CarReport"
        Me.Text = "CarReport"
        Me.GroupBox3.ResumeLayout(False)
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CarReportBindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CARRENTINGSYSTEMDBDataSet13BindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CAR_RENTING_SYSTEM_DBDataSet13, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.CarReportBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents TextBoxSurname As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents TextBoxFirstname As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents TextBoxIDNumber As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents GroupBox5 As GroupBox
    Friend WithEvents Label8 As Label
    Friend WithEvents TextBoxManufucture As TextBox
    Friend WithEvents Label15 As Label
    Friend WithEvents TextBoxModel As TextBox
    Friend WithEvents TextBoxPricePerDay As TextBox
    Friend WithEvents Label11 As Label
    Friend WithEvents TextBoxDayofRent As TextBox
    Friend WithEvents TextBoxRentWithDriver As TextBox
    Friend WithEvents TextBoxTotalPrice As TextBox
    Friend WithEvents TextBoxPlateNumber As TextBox
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents TextBoxNumberOfDay As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents TextBoxContactNo As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents TextBoxTCode As TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents TextBoxDatetoretun As TextBox
    Friend WithEvents Label14 As Label
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents CAR_RENTING_SYSTEM_DBDataSet13 As CAR_RENTING_SYSTEM_DBDataSet13
    Friend WithEvents CarReportBindingSource As BindingSource
    Friend WithEvents CarReportTableAdapter As CAR_RENTING_SYSTEM_DBDataSet13TableAdapters.CarReportTableAdapter
    Friend WithEvents IDNumberDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents FirstnameDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents SurnameDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents ContactNoDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents TransactionCodeDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents PlateNumberDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents ManufactureDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents ModelDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents PricePerDayDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents RentWithDriveDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents NumberOfDaysDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents TotalPriceDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents DateOfRentingDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents DateRetunCarDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents CarReportBindingSource1 As BindingSource
    Friend WithEvents CARRENTINGSYSTEMDBDataSet13BindingSource As BindingSource
End Class
