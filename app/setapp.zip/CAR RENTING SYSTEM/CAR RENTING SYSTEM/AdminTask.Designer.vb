﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AdminTask
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(AdminTask))
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.NocarBookedBTN = New System.Windows.Forms.Button()
        Me.CheckBooker = New System.Windows.Forms.Button()
        Me.CarReportBTN = New System.Windows.Forms.Button()
        Me.AddDeleteCar = New System.Windows.Forms.Button()
        Me.AddDeleteUser = New System.Windows.Forms.Button()
        Me.NewAdminBTN = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox1.Controls.Add(Me.NocarBookedBTN)
        Me.GroupBox1.Controls.Add(Me.CheckBooker)
        Me.GroupBox1.Controls.Add(Me.CarReportBTN)
        Me.GroupBox1.Controls.Add(Me.AddDeleteCar)
        Me.GroupBox1.Controls.Add(Me.AddDeleteUser)
        Me.GroupBox1.Location = New System.Drawing.Point(425, 142)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(244, 320)
        Me.GroupBox1.TabIndex = 5
        Me.GroupBox1.TabStop = False
        '
        'NocarBookedBTN
        '
        Me.NocarBookedBTN.BackColor = System.Drawing.Color.Black
        Me.NocarBookedBTN.Font = New System.Drawing.Font("Algerian", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NocarBookedBTN.ForeColor = System.Drawing.Color.DarkRed
        Me.NocarBookedBTN.Location = New System.Drawing.Point(27, 37)
        Me.NocarBookedBTN.Name = "NocarBookedBTN"
        Me.NocarBookedBTN.Size = New System.Drawing.Size(188, 47)
        Me.NocarBookedBTN.TabIndex = 12
        Me.NocarBookedBTN.Text = "Check For Booker"
        Me.NocarBookedBTN.UseVisualStyleBackColor = False
        '
        'CheckBooker
        '
        Me.CheckBooker.BackColor = System.Drawing.Color.Black
        Me.CheckBooker.Font = New System.Drawing.Font("Algerian", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBooker.ForeColor = System.Drawing.Color.DarkRed
        Me.CheckBooker.Location = New System.Drawing.Point(27, 37)
        Me.CheckBooker.Name = "CheckBooker"
        Me.CheckBooker.Size = New System.Drawing.Size(188, 47)
        Me.CheckBooker.TabIndex = 6
        Me.CheckBooker.Text = "Check For Booker"
        Me.CheckBooker.UseVisualStyleBackColor = False
        Me.CheckBooker.Visible = False
        '
        'CarReportBTN
        '
        Me.CarReportBTN.BackColor = System.Drawing.Color.Black
        Me.CarReportBTN.Font = New System.Drawing.Font("Algerian", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CarReportBTN.ForeColor = System.Drawing.Color.DarkRed
        Me.CarReportBTN.Location = New System.Drawing.Point(27, 236)
        Me.CarReportBTN.Name = "CarReportBTN"
        Me.CarReportBTN.Size = New System.Drawing.Size(188, 47)
        Me.CarReportBTN.TabIndex = 10
        Me.CarReportBTN.Text = "Car Report"
        Me.CarReportBTN.UseVisualStyleBackColor = False
        '
        'AddDeleteCar
        '
        Me.AddDeleteCar.BackColor = System.Drawing.Color.Black
        Me.AddDeleteCar.Font = New System.Drawing.Font("Algerian", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddDeleteCar.ForeColor = System.Drawing.Color.DarkRed
        Me.AddDeleteCar.Location = New System.Drawing.Point(27, 99)
        Me.AddDeleteCar.Name = "AddDeleteCar"
        Me.AddDeleteCar.Size = New System.Drawing.Size(188, 47)
        Me.AddDeleteCar.TabIndex = 8
        Me.AddDeleteCar.Text = "Cars Information"
        Me.AddDeleteCar.UseVisualStyleBackColor = False
        '
        'AddDeleteUser
        '
        Me.AddDeleteUser.BackColor = System.Drawing.Color.Black
        Me.AddDeleteUser.Font = New System.Drawing.Font("Algerian", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddDeleteUser.ForeColor = System.Drawing.Color.DarkRed
        Me.AddDeleteUser.Location = New System.Drawing.Point(27, 163)
        Me.AddDeleteUser.Name = "AddDeleteUser"
        Me.AddDeleteUser.Size = New System.Drawing.Size(188, 47)
        Me.AddDeleteUser.TabIndex = 9
        Me.AddDeleteUser.Text = "User's Information"
        Me.AddDeleteUser.UseVisualStyleBackColor = False
        '
        'NewAdminBTN
        '
        Me.NewAdminBTN.BackColor = System.Drawing.Color.DarkRed
        Me.NewAdminBTN.Font = New System.Drawing.Font("Modern No. 20", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NewAdminBTN.ForeColor = System.Drawing.Color.Black
        Me.NewAdminBTN.Location = New System.Drawing.Point(854, 542)
        Me.NewAdminBTN.Name = "NewAdminBTN"
        Me.NewAdminBTN.Size = New System.Drawing.Size(159, 33)
        Me.NewAdminBTN.TabIndex = 11
        Me.NewAdminBTN.Text = "Add New Admin"
        Me.NewAdminBTN.UseVisualStyleBackColor = False
        '
        'AdminTask
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.CAR_RENTING_SYSTEM.My.Resources.Resources.Maserati
        Me.ClientSize = New System.Drawing.Size(1025, 619)
        Me.Controls.Add(Me.NewAdminBTN)
        Me.Controls.Add(Me.GroupBox1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "AdminTask"
        Me.Text = "AdminTask"
        Me.GroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents CheckBooker As Button
    Friend WithEvents CarReportBTN As Button
    Friend WithEvents AddDeleteCar As Button
    Friend WithEvents AddDeleteUser As Button
    Friend WithEvents NewAdminBTN As Button
    Friend WithEvents NocarBookedBTN As Button
End Class
