﻿Imports System.Data.SqlClient
Imports System.IO
Public Class Cars
    Dim table As New DataTable()
    Dim table1 As New DataTable()
    Dim connection As New SqlConnection("Server = DESKTOP-N7870M5; Database = CAR RENTING SYSTEM DB; Integrated Security = true")
    Dim index As Integer = 0
    Private Sub Cars_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.Text = "CHOOSE A CAR YOU WANT TO BORROW "
        showData(index)


    End Sub

    Public Sub showData(position As Integer)
        Dim comm As New SqlCommand("Select * from Carinformation", connection)
        Dim adapter1 As New SqlDataAdapter(comm)
        adapter1.Fill(table)
        TextBox8.Text = table.Rows(position)(9).ToString()

        If TextBox8.Text = "False" Then

            Dim command As New SqlCommand("Select * from Carinformation ", connection)
            Dim adapter As New SqlDataAdapter(command)
            adapter.Fill(table)
            TextBox1.Text = table.Rows(position)(0).ToString()
            TextBox2.Text = table.Rows(position)(1).ToString()
            TextBox3.Text = table.Rows(position)(2).ToString()
            TextBox4.Text = table.Rows(position)(3).ToString()
            TextBox5.Text = table.Rows(position)(4).ToString()
            TextBox6.Text = table.Rows(position)(5).ToString()
            TextBox7.Text = table.Rows(position)(8).ToString()
            Dim picbyte() As Byte = table.Rows(position).Item("image")
            Dim pic As New System.IO.MemoryStream(picbyte)
            PictureBox1.Image = Image.FromStream(pic)
            PictureBox1.SizeMode = PictureBoxSizeMode.StretchImage
            pic.Close()

        Else
            index += 1
            If index > table.Rows.Count() - 1 Then
                index = table.Rows.Count() - 1

            End If
            showData(index)
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles FirstBTN.Click
        index = 0
        showData(index)
    End Sub

    Private Sub NextBtn_Click(sender As Object, e As EventArgs) Handles NextBtn.Click
        index += 1
        If index > table.Rows.Count() - 1 Then
            index = table.Rows.Count() - 1
        End If
        showData(index)
    End Sub

    Private Sub BackBtn_Click(sender As Object, e As EventArgs) Handles BackBtn.Click
        index -= 1
        If index < 0 Then
            index = 0
        End If
        showData(index)
    End Sub

    Private Sub LastBTN_Click(sender As Object, e As EventArgs) Handles LastBTN.Click
        index = table.Rows.Count() - 1
        showData(index)
    End Sub

    Private Sub BookBtn_Click(sender As Object, e As EventArgs) Handles BookBtn.Click
        fullform.Show()
        Me.Hide()
    End Sub

End Class