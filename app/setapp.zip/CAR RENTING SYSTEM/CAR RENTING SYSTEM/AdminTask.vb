﻿Public Class AdminTask
    Private Sub AdminTask_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.MaximizeBox = False
        Me.Text = "ADMIN TASK"
        loginboth.Show()
    End Sub

    Private Sub CheckBooker_Click(sender As Object, e As EventArgs) Handles CheckBooker.Click
        CheckForBooker.Show()
        Me.Hide()
    End Sub
    Private Sub AddDeleteCar_Click_1(sender As Object, e As EventArgs) Handles AddDeleteCar.Click
        AdminCars.Show()

    End Sub

    Private Sub AddDeleteUser_Click_1(sender As Object, e As EventArgs) Handles AddDeleteUser.Click
        UsersInformation.Show()

    End Sub

    Private Sub CarReportBTN_Click(sender As Object, e As EventArgs) Handles CarReportBTN.Click
        CarReport.Show()

    End Sub

    Private Sub NewAdminBTN_Click(sender As Object, e As EventArgs) Handles NewAdminBTN.Click
        AdminRegistration.Show()
        Me.Hide()
        AdminRegistration.GroupBox3.Visible = True
        AdminRegistration.Addnewadmin.Visible = False
        AdminRegistration.SubmAdminBtn.Visible = False

    End Sub

    Private Sub NocarBookedBTN_Click(sender As Object, e As EventArgs) Handles NocarBookedBTN.Click
        MsgBox("THERE IS NO REQUEST TO RENT A CAR", MsgBoxStyle.OkOnly, "NO RENT")

    End Sub
End Class