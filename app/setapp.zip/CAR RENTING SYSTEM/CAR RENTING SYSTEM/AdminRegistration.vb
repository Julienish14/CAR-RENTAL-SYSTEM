﻿Imports System.Data.SqlClient
Public Class AdminRegistration
    Dim con As New SqlConnection("server= DESKTOP-N7870M5; database= CAR RENTING SYSTEM DB; Integrated Security = true")
    Private Sub SubmAdminBtn_Click(sender As Object, e As EventArgs) Handles SubmAdminBtn.Click
        If TextBox1.Text = String.Empty Or TextBox2.Text = String.Empty Or TextBox3.Text = String.Empty Or TextBox4.Text = String.Empty Or TextBox5.Text = String.Empty Or TextBox6.Text = String.Empty Then
            MsgBox("FILL NEW ADMIN INFORMATION BEFORE YOU SUBMIT", MsgBoxStyle.Information, "     ERROR")
        Else



            Dim command As New SqlCommand("insert into Admininformation (CampanyName,Telephone,Email,Location,Admin_Name,Password) VALUES (@CampanyName,@Telephone,@Email,@Location,@Admin_Name,@Password)", con)
            command.Parameters.Add("@CampanyName", SqlDbType.VarChar).Value = TextBox1.Text
            command.Parameters.Add("@Telephone", SqlDbType.VarChar).Value = TextBox2.Text
            command.Parameters.Add("@Email", SqlDbType.VarChar).Value = TextBox3.Text
            command.Parameters.Add("@Location", SqlDbType.VarChar).Value = TextBox4.Text
            command.Parameters.Add("@Admin_Name", SqlDbType.VarChar).Value = TextBox5.Text
            command.Parameters.Add("@Password", SqlDbType.VarChar).Value = TextBox6.Text

            con.Open()

            If command.ExecuteNonQuery() = 1 Then
                MsgBox("ADMIN  " + TextBox5.Text + "  ADDED IN SYSTEM", MsgBoxStyle.Information, "WELCOME NEW ADMIN")
                loaddata(" ")
            Else
                MsgBox("NOT INSERTED", MsgBoxStyle.Information)
            End If
            con.Close()
        End If
    End Sub
    Private Sub AdminRegistration_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'CAR_RENTING_SYSTEM_DBDataSet12.Admininformation' table. You can move, or remove it, as needed.
        Me.AdmininformationTableAdapter.Fill(Me.CAR_RENTING_SYSTEM_DBDataSet12.Admininformation)
        Me.Text = " ADMINISTRATION MANAGEMENT  "
        Me.MaximizeBox = False
    End Sub

    Private Sub CancelAdminBTN_Click(sender As Object, e As EventArgs) Handles DeleteAdminBTN.Click

        Dim command As New SqlCommand("delete from Admininformation where Admin_Name = @Admin_Name", con)
        command.Parameters.Add("@Admin_Name", SqlDbType.VarChar).Value = TextBox5.Text

        Dim adapter As New SqlDataAdapter(command)

        Dim table As New DataTable()

        adapter.Fill(table)

        If table.Rows.Count() <= 1 Then
            MsgBox(" ADMIN   " + TextBox5.Text + "  DELETED  IN THE STSTEM", MsgBoxStyle.Information, "DELETE ADMIN ACCOUNT")
            loaddata(" ")

        Else
            MessageBox.Show("ADMIN not Deleted")
        End If
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        Try
            Dim i As Integer
            i = DataGridView1.CurrentRow.Index
            Me.TextBox1.Text = DataGridView1.Item(0, i).Value
            Me.TextBox2.Text = DataGridView1.Item(1, i).Value
            Me.TextBox3.Text = DataGridView1.Item(2, i).Value
            Me.TextBox4.Text = DataGridView1.Item(3, i).Value
            Me.TextBox5.Text = DataGridView1.Item(4, i).Value
            Me.TextBox6.Text = DataGridView1.Item(5, i).Value
            Addnewadmin.Visible = True
            SubmAdminBtn.Visible = False
            DeleteAdminBTN.Visible = True

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub
    Sub loaddata(ByVal search As String)
        Dim query As String = "SELECT * FROM Admininformation"
        Dim cmd As New SqlCommand
        cmd = New SqlCommand(query, con)
        Dim da = New SqlDataAdapter(cmd)
        Dim dt As New DataTable
        da.Fill(dt)
        DataGridView1.DataSource = dt
    End Sub

    Private Sub Addnewadmin_Click(sender As Object, e As EventArgs) Handles Addnewadmin.Click
        Addnewadmin.Visible = False
        SubmAdminBtn.Visible = True
        DeleteAdminBTN.Visible = False
        TextBox1.Clear()
        TextBox2.Clear()
        TextBox3.Clear()
        TextBox4.Clear()
        TextBox5.Clear()
        TextBox6.Clear()

    End Sub

    Private Sub loginAdmnConfimBtn_Click(sender As Object, e As EventArgs) Handles loginAdmnConfimBtn.Click

        If TextboxAdmin.Text = String.Empty And TextAdminPassword.Text = String.Empty Then
            MsgBox("Admin Username And Password is Empty ", MsgBoxStyle.Information, "ADMIN LOGIN ")
        ElseIf TextboxAdmin.Text = String.Empty Then
            MsgBox("Username is Empty ", MsgBoxStyle.Information, "ADMIN LOGIN")
        ElseIf TextAdminPassword.Text = String.Empty Then
            MsgBox("Password is Empty", MsgBoxStyle.Information, "ADMIN LOGIN ")
        Else

            Dim command As New SqlCommand("select * from Admininformation where Admin_Name = @Admin_Name and Password = @Password ", con)

            command.Parameters.Add("@Admin_Name", SqlDbType.VarChar).Value = TextboxAdmin.Text
            command.Parameters.Add("@Password", SqlDbType.VarChar).Value = TextAdminPassword.Text

            Dim adapter As New SqlDataAdapter(command)

            Dim table As New DataTable()

            adapter.Fill(table)

            If table.Rows.Count() <= 0 Then
                MsgBox("Your UserName Or Password is Incorrect", MsgBoxStyle.Exclamation, "ADMIN NAME AND PASSWORD")
            Else

                GroupBox1.Visible = True
                GroupBox2.Visible = True
                cancelAdminconfirmBtn.Visible = True
                Addnewadmin.Visible = False
                SubmAdminBtn.Visible = True
                GroupBox3.Visible = False


            End If
        End If
    End Sub

    Private Sub cancelAdminconfirmBtn_Click(sender As Object, e As EventArgs) Handles cancelAdminconfirmBtn.Click
        Close()
    End Sub

    Private Sub GroupBox3_Enter(sender As Object, e As EventArgs) Handles GroupBox3.Enter
        TextAdminPassword.UseSystemPasswordChar = True
    End Sub

    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles Button1.Click
        If TextAdminPassword.UseSystemPasswordChar = True Then
            TextAdminPassword.UseSystemPasswordChar = False
        Else
            TextAdminPassword.UseSystemPasswordChar = True
        End If
    End Sub
End Class