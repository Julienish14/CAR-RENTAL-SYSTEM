﻿Public Class loginboth
    Private Sub AdminBtn_Click(sender As Object, e As EventArgs) Handles AdminBtn.Click
        adminLogin.Show()
        Me.Hide()
    End Sub

    Private Sub UserBtn_Click(sender As Object, e As EventArgs) Handles UserBtn.Click
        userLogin.Show()
        Me.Hide()
    End Sub

    Private Sub loginboth_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.Text = "LOGIN PAGE"
        Me.MaximizeBox = False
    End Sub
End Class