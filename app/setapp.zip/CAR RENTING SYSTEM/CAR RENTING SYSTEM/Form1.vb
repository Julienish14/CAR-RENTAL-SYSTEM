﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles ContinueBtn.Click
        loginboth.Show()

        Me.Hide()
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.Text = "WELCOME"
    End Sub
End Class
