﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class CheckForBooker
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(CheckForBooker))
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.TextBoxContactNumber = New System.Windows.Forms.TextBox()
        Me.TextBoxUsername = New System.Windows.Forms.TextBox()
        Me.TextBoxSurname = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TextBoxFirstname = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TextBoxIDNumber = New System.Windows.Forms.TextBox()
        Me.BackgroundWorker1 = New System.ComponentModel.BackgroundWorker()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.TextBoxDateOfReturn = New System.Windows.Forms.TextBox()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Discount = New System.Windows.Forms.Label()
        Me.TextBoxTotolPric = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.TextBoxDiscount = New System.Windows.Forms.TextBox()
        Me.TextBoxDateOfRent = New System.Windows.Forms.TextBox()
        Me.TextBoxNumberOfDay = New System.Windows.Forms.TextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.TextBoxRentWithDriver = New System.Windows.Forms.TextBox()
        Me.TextBox12 = New System.Windows.Forms.TextBox()
        Me.TextBoxSubTotalPrice = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.TextBoxPircePerDay = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.TextBoxPlateNumber = New System.Windows.Forms.TextBox()
        Me.TextBoxYearofMaker = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.TextBoxManufacture = New System.Windows.Forms.TextBox()
        Me.TextBoxColor = New System.Windows.Forms.TextBox()
        Me.TextBoxModel = New System.Windows.Forms.TextBox()
        Me.ConfrmBookerBTN = New System.Windows.Forms.Button()
        Me.TextBox16 = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.TextBox18 = New System.Windows.Forms.TextBox()
        Me.DenyBTN = New System.Windows.Forms.Button()
        Me.PictureBoxBooker = New System.Windows.Forms.PictureBox()
        Me.RadioButton4 = New System.Windows.Forms.RadioButton()
        Me.RadioButton3 = New System.Windows.Forms.RadioButton()
        Me.UpdateStatusBTN = New System.Windows.Forms.Button()
        Me.TCodeBTN = New System.Windows.Forms.Button()
        Me.TextBoxTcode = New System.Windows.Forms.TextBox()
        Me.TextBoxCampanyNa = New System.Windows.Forms.TextBox()
        Me.TextBoxContactN = New System.Windows.Forms.TextBox()
        Me.TextBoxEmail = New System.Windows.Forms.TextBox()
        Me.TextBoxLocation = New System.Windows.Forms.TextBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.PictureBoxBooker, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.Gray
        Me.GroupBox1.Controls.Add(Me.Label14)
        Me.GroupBox1.Controls.Add(Me.TextBoxContactNumber)
        Me.GroupBox1.Controls.Add(Me.TextBoxUsername)
        Me.GroupBox1.Controls.Add(Me.TextBoxSurname)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.TextBoxFirstname)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.TextBoxIDNumber)
        Me.GroupBox1.Font = New System.Drawing.Font("Rockwell", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.ForeColor = System.Drawing.Color.Black
        Me.GroupBox1.Location = New System.Drawing.Point(130, 118)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(321, 226)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "CUSTORMER INFO"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.BackColor = System.Drawing.Color.Transparent
        Me.Label14.Font = New System.Drawing.Font("Monotype Corsiva", 15.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.ForeColor = System.Drawing.Color.Black
        Me.Label14.Location = New System.Drawing.Point(6, 101)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(107, 25)
        Me.Label14.TabIndex = 16
        Me.Label14.Text = "Username :"
        '
        'TextBoxContactNumber
        '
        Me.TextBoxContactNumber.Font = New System.Drawing.Font("Rockwell", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxContactNumber.Location = New System.Drawing.Point(125, 135)
        Me.TextBoxContactNumber.Name = "TextBoxContactNumber"
        Me.TextBoxContactNumber.ReadOnly = True
        Me.TextBoxContactNumber.Size = New System.Drawing.Size(174, 26)
        Me.TextBoxContactNumber.TabIndex = 15
        Me.TextBoxContactNumber.TabStop = False
        '
        'TextBoxUsername
        '
        Me.TextBoxUsername.Font = New System.Drawing.Font("Rockwell", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxUsername.Location = New System.Drawing.Point(125, 103)
        Me.TextBoxUsername.Name = "TextBoxUsername"
        Me.TextBoxUsername.ReadOnly = True
        Me.TextBoxUsername.Size = New System.Drawing.Size(174, 26)
        Me.TextBoxUsername.TabIndex = 14
        Me.TextBoxUsername.TabStop = False
        '
        'TextBoxSurname
        '
        Me.TextBoxSurname.Font = New System.Drawing.Font("Rockwell", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxSurname.Location = New System.Drawing.Point(125, 72)
        Me.TextBoxSurname.Name = "TextBoxSurname"
        Me.TextBoxSurname.ReadOnly = True
        Me.TextBoxSurname.Size = New System.Drawing.Size(174, 26)
        Me.TextBoxSurname.TabIndex = 13
        Me.TextBoxSurname.TabStop = False
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Monotype Corsiva", 15.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.Black
        Me.Label4.Location = New System.Drawing.Point(6, 168)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(115, 25)
        Me.Label4.TabIndex = 12
        Me.Label4.Text = "IDNumber :"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Font = New System.Drawing.Font("Monotype Corsiva", 15.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.Black
        Me.Label3.Location = New System.Drawing.Point(6, 133)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(115, 25)
        Me.Label3.TabIndex = 11
        Me.Label3.Text = "ContactNo :"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Monotype Corsiva", 15.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Location = New System.Drawing.Point(6, 70)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(96, 25)
        Me.Label2.TabIndex = 10
        Me.Label2.Text = "Surname :"
        '
        'TextBoxFirstname
        '
        Me.TextBoxFirstname.Font = New System.Drawing.Font("Rockwell", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxFirstname.Location = New System.Drawing.Point(125, 40)
        Me.TextBoxFirstname.Name = "TextBoxFirstname"
        Me.TextBoxFirstname.ReadOnly = True
        Me.TextBoxFirstname.Size = New System.Drawing.Size(174, 26)
        Me.TextBoxFirstname.TabIndex = 9
        Me.TextBoxFirstname.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Monotype Corsiva", 15.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Black
        Me.Label1.Location = New System.Drawing.Point(6, 40)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(109, 25)
        Me.Label1.TabIndex = 8
        Me.Label1.Text = "Firstname :"
        '
        'TextBoxIDNumber
        '
        Me.TextBoxIDNumber.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxIDNumber.Location = New System.Drawing.Point(125, 169)
        Me.TextBoxIDNumber.Name = "TextBoxIDNumber"
        Me.TextBoxIDNumber.ReadOnly = True
        Me.TextBoxIDNumber.Size = New System.Drawing.Size(174, 22)
        Me.TextBoxIDNumber.TabIndex = 33
        Me.TextBoxIDNumber.TabStop = False
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.Gray
        Me.GroupBox2.Controls.Add(Me.TextBoxDateOfReturn)
        Me.GroupBox2.Controls.Add(Me.Label23)
        Me.GroupBox2.Controls.Add(Me.Discount)
        Me.GroupBox2.Controls.Add(Me.TextBoxTotolPric)
        Me.GroupBox2.Controls.Add(Me.Label15)
        Me.GroupBox2.Controls.Add(Me.TextBoxDiscount)
        Me.GroupBox2.Controls.Add(Me.TextBoxDateOfRent)
        Me.GroupBox2.Controls.Add(Me.TextBoxNumberOfDay)
        Me.GroupBox2.Controls.Add(Me.Label19)
        Me.GroupBox2.Controls.Add(Me.TextBoxRentWithDriver)
        Me.GroupBox2.Controls.Add(Me.TextBox12)
        Me.GroupBox2.Controls.Add(Me.TextBoxSubTotalPrice)
        Me.GroupBox2.Controls.Add(Me.Label12)
        Me.GroupBox2.Controls.Add(Me.Label13)
        Me.GroupBox2.Controls.Add(Me.Label18)
        Me.GroupBox2.Controls.Add(Me.TextBoxPircePerDay)
        Me.GroupBox2.Controls.Add(Me.Label8)
        Me.GroupBox2.Controls.Add(Me.Label5)
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Controls.Add(Me.Label9)
        Me.GroupBox2.Controls.Add(Me.Label10)
        Me.GroupBox2.Controls.Add(Me.TextBoxPlateNumber)
        Me.GroupBox2.Controls.Add(Me.TextBoxYearofMaker)
        Me.GroupBox2.Controls.Add(Me.Label11)
        Me.GroupBox2.Controls.Add(Me.TextBoxManufacture)
        Me.GroupBox2.Controls.Add(Me.TextBoxColor)
        Me.GroupBox2.Controls.Add(Me.TextBoxModel)
        Me.GroupBox2.Font = New System.Drawing.Font("Rockwell", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.ForeColor = System.Drawing.Color.Black
        Me.GroupBox2.Location = New System.Drawing.Point(457, 118)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(764, 226)
        Me.GroupBox2.TabIndex = 1
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "BOOKED CAR"
        '
        'TextBoxDateOfReturn
        '
        Me.TextBoxDateOfReturn.Font = New System.Drawing.Font("Rockwell", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxDateOfReturn.Location = New System.Drawing.Point(521, 190)
        Me.TextBoxDateOfReturn.Name = "TextBoxDateOfReturn"
        Me.TextBoxDateOfReturn.ReadOnly = True
        Me.TextBoxDateOfReturn.Size = New System.Drawing.Size(131, 26)
        Me.TextBoxDateOfReturn.TabIndex = 54
        Me.TextBoxDateOfReturn.TabStop = False
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.BackColor = System.Drawing.Color.Transparent
        Me.Label23.Font = New System.Drawing.Font("Monotype Corsiva", 15.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.ForeColor = System.Drawing.Color.Black
        Me.Label23.Location = New System.Drawing.Point(321, 188)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(201, 25)
        Me.Label23.TabIndex = 53
        Me.Label23.Text = "Date of Return a car :"
        '
        'Discount
        '
        Me.Discount.AutoSize = True
        Me.Discount.Font = New System.Drawing.Font("Rockwell", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Discount.Location = New System.Drawing.Point(459, 42)
        Me.Discount.Name = "Discount"
        Me.Discount.Size = New System.Drawing.Size(73, 18)
        Me.Discount.TabIndex = 50
        Me.Discount.Text = "Discount"
        Me.Discount.Visible = False
        '
        'TextBoxTotolPric
        '
        Me.TextBoxTotolPric.Font = New System.Drawing.Font("Rockwell", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxTotolPric.Location = New System.Drawing.Point(546, 62)
        Me.TextBoxTotolPric.Name = "TextBoxTotolPric"
        Me.TextBoxTotolPric.Size = New System.Drawing.Size(81, 25)
        Me.TextBoxTotolPric.TabIndex = 49
        Me.TextBoxTotolPric.Visible = False
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.BackColor = System.Drawing.Color.Transparent
        Me.Label15.Font = New System.Drawing.Font("Monotype Corsiva", 15.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.Color.Black
        Me.Label15.Location = New System.Drawing.Point(321, 161)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(162, 25)
        Me.Label15.TabIndex = 47
        Me.Label15.Text = "Date of Renting :"
        '
        'TextBoxDiscount
        '
        Me.TextBoxDiscount.Font = New System.Drawing.Font("Rockwell", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxDiscount.Location = New System.Drawing.Point(546, 39)
        Me.TextBoxDiscount.Name = "TextBoxDiscount"
        Me.TextBoxDiscount.Size = New System.Drawing.Size(81, 25)
        Me.TextBoxDiscount.TabIndex = 48
        Me.TextBoxDiscount.Visible = False
        '
        'TextBoxDateOfRent
        '
        Me.TextBoxDateOfRent.Font = New System.Drawing.Font("Rockwell", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxDateOfRent.Location = New System.Drawing.Point(521, 162)
        Me.TextBoxDateOfRent.Name = "TextBoxDateOfRent"
        Me.TextBoxDateOfRent.ReadOnly = True
        Me.TextBoxDateOfRent.Size = New System.Drawing.Size(131, 26)
        Me.TextBoxDateOfRent.TabIndex = 46
        Me.TextBoxDateOfRent.TabStop = False
        '
        'TextBoxNumberOfDay
        '
        Me.TextBoxNumberOfDay.Font = New System.Drawing.Font("Rockwell", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxNumberOfDay.Location = New System.Drawing.Point(521, 135)
        Me.TextBoxNumberOfDay.Name = "TextBoxNumberOfDay"
        Me.TextBoxNumberOfDay.ReadOnly = True
        Me.TextBoxNumberOfDay.Size = New System.Drawing.Size(59, 26)
        Me.TextBoxNumberOfDay.TabIndex = 45
        Me.TextBoxNumberOfDay.TabStop = False
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Rockwell", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(459, 18)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(67, 18)
        Me.Label19.TabIndex = 52
        Me.Label19.Text = "Subtotal"
        Me.Label19.Visible = False
        '
        'TextBoxRentWithDriver
        '
        Me.TextBoxRentWithDriver.Font = New System.Drawing.Font("Rockwell", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxRentWithDriver.Location = New System.Drawing.Point(521, 109)
        Me.TextBoxRentWithDriver.Name = "TextBoxRentWithDriver"
        Me.TextBoxRentWithDriver.ReadOnly = True
        Me.TextBoxRentWithDriver.Size = New System.Drawing.Size(59, 26)
        Me.TextBoxRentWithDriver.TabIndex = 44
        Me.TextBoxRentWithDriver.TabStop = False
        '
        'TextBox12
        '
        Me.TextBox12.Font = New System.Drawing.Font("Rockwell", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox12.Location = New System.Drawing.Point(521, 80)
        Me.TextBox12.Name = "TextBox12"
        Me.TextBox12.ReadOnly = True
        Me.TextBox12.Size = New System.Drawing.Size(100, 26)
        Me.TextBox12.TabIndex = 43
        Me.TextBox12.TabStop = False
        '
        'TextBoxSubTotalPrice
        '
        Me.TextBoxSubTotalPrice.Font = New System.Drawing.Font("Rockwell", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxSubTotalPrice.Location = New System.Drawing.Point(546, 15)
        Me.TextBoxSubTotalPrice.Name = "TextBoxSubTotalPrice"
        Me.TextBoxSubTotalPrice.Size = New System.Drawing.Size(81, 25)
        Me.TextBoxSubTotalPrice.TabIndex = 6
        Me.TextBoxSubTotalPrice.TabStop = False
        Me.TextBoxSubTotalPrice.Visible = False
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.BackColor = System.Drawing.Color.Transparent
        Me.Label12.Font = New System.Drawing.Font("Monotype Corsiva", 15.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.Color.Black
        Me.Label12.Location = New System.Drawing.Point(321, 109)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(170, 25)
        Me.Label12.TabIndex = 41
        Me.Label12.Text = "Rent with Driver :"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.BackColor = System.Drawing.Color.Transparent
        Me.Label13.Font = New System.Drawing.Font("Monotype Corsiva", 15.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.ForeColor = System.Drawing.Color.Black
        Me.Label13.Location = New System.Drawing.Point(321, 135)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(154, 25)
        Me.Label13.TabIndex = 42
        Me.Label13.Text = "Number of Day :"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Rockwell", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(447, 64)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(98, 18)
        Me.Label18.TabIndex = 51
        Me.Label18.Text = "Total Price :"
        Me.Label18.Visible = False
        '
        'TextBoxPircePerDay
        '
        Me.TextBoxPircePerDay.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxPircePerDay.Location = New System.Drawing.Point(156, 187)
        Me.TextBoxPircePerDay.Name = "TextBoxPircePerDay"
        Me.TextBoxPircePerDay.ReadOnly = True
        Me.TextBoxPircePerDay.Size = New System.Drawing.Size(159, 22)
        Me.TextBoxPircePerDay.TabIndex = 40
        Me.TextBoxPircePerDay.TabStop = False
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.Font = New System.Drawing.Font("Monotype Corsiva", 15.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.Black
        Me.Label8.Location = New System.Drawing.Point(321, 81)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(169, 25)
        Me.Label8.TabIndex = 39
        Me.Label8.Text = "Car Transmission :"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Font = New System.Drawing.Font("Monotype Corsiva", 15.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.Black
        Me.Label5.Location = New System.Drawing.Point(6, 63)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(142, 25)
        Me.Label5.TabIndex = 28
        Me.Label5.Text = "Manufacturer :"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.Font = New System.Drawing.Font("Monotype Corsiva", 15.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.Black
        Me.Label6.Location = New System.Drawing.Point(6, 33)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(141, 25)
        Me.Label6.TabIndex = 27
        Me.Label6.Text = "Plate Number :"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.Font = New System.Drawing.Font("Monotype Corsiva", 15.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.Black
        Me.Label7.Location = New System.Drawing.Point(6, 95)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(76, 25)
        Me.Label7.TabIndex = 29
        Me.Label7.Text = "Model :"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.Font = New System.Drawing.Font("Monotype Corsiva", 15.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.Black
        Me.Label9.Location = New System.Drawing.Point(6, 124)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(67, 25)
        Me.Label9.TabIndex = 30
        Me.Label9.Text = "Color :"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.Transparent
        Me.Label10.Font = New System.Drawing.Font("Monotype Corsiva", 15.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.Black
        Me.Label10.Location = New System.Drawing.Point(6, 154)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(145, 25)
        Me.Label10.TabIndex = 32
        Me.Label10.Text = "Year of Maker :"
        '
        'TextBoxPlateNumber
        '
        Me.TextBoxPlateNumber.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxPlateNumber.Location = New System.Drawing.Point(156, 34)
        Me.TextBoxPlateNumber.Margin = New System.Windows.Forms.Padding(1)
        Me.TextBoxPlateNumber.Name = "TextBoxPlateNumber"
        Me.TextBoxPlateNumber.ReadOnly = True
        Me.TextBoxPlateNumber.Size = New System.Drawing.Size(159, 22)
        Me.TextBoxPlateNumber.TabIndex = 34
        Me.TextBoxPlateNumber.TabStop = False
        '
        'TextBoxYearofMaker
        '
        Me.TextBoxYearofMaker.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxYearofMaker.Location = New System.Drawing.Point(156, 157)
        Me.TextBoxYearofMaker.Name = "TextBoxYearofMaker"
        Me.TextBoxYearofMaker.ReadOnly = True
        Me.TextBoxYearofMaker.Size = New System.Drawing.Size(159, 22)
        Me.TextBoxYearofMaker.TabIndex = 38
        Me.TextBoxYearofMaker.TabStop = False
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.BackColor = System.Drawing.Color.Transparent
        Me.Label11.Font = New System.Drawing.Font("Monotype Corsiva", 15.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.Black
        Me.Label11.Location = New System.Drawing.Point(6, 182)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(141, 25)
        Me.Label11.TabIndex = 31
        Me.Label11.Text = "Price Per Day :"
        '
        'TextBoxManufacture
        '
        Me.TextBoxManufacture.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxManufacture.Location = New System.Drawing.Point(156, 64)
        Me.TextBoxManufacture.Name = "TextBoxManufacture"
        Me.TextBoxManufacture.ReadOnly = True
        Me.TextBoxManufacture.Size = New System.Drawing.Size(159, 22)
        Me.TextBoxManufacture.TabIndex = 35
        Me.TextBoxManufacture.TabStop = False
        '
        'TextBoxColor
        '
        Me.TextBoxColor.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxColor.Location = New System.Drawing.Point(156, 127)
        Me.TextBoxColor.Name = "TextBoxColor"
        Me.TextBoxColor.ReadOnly = True
        Me.TextBoxColor.Size = New System.Drawing.Size(159, 22)
        Me.TextBoxColor.TabIndex = 37
        Me.TextBoxColor.TabStop = False
        '
        'TextBoxModel
        '
        Me.TextBoxModel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxModel.Location = New System.Drawing.Point(156, 96)
        Me.TextBoxModel.Name = "TextBoxModel"
        Me.TextBoxModel.ReadOnly = True
        Me.TextBoxModel.Size = New System.Drawing.Size(159, 22)
        Me.TextBoxModel.TabIndex = 36
        Me.TextBoxModel.TabStop = False
        '
        'ConfrmBookerBTN
        '
        Me.ConfrmBookerBTN.BackColor = System.Drawing.Color.Black
        Me.ConfrmBookerBTN.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ConfrmBookerBTN.Font = New System.Drawing.Font("Algerian", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ConfrmBookerBTN.ForeColor = System.Drawing.SystemColors.ControlLight
        Me.ConfrmBookerBTN.Location = New System.Drawing.Point(828, 488)
        Me.ConfrmBookerBTN.Name = "ConfrmBookerBTN"
        Me.ConfrmBookerBTN.Size = New System.Drawing.Size(209, 65)
        Me.ConfrmBookerBTN.TabIndex = 3
        Me.ConfrmBookerBTN.Text = "CONFIRM RENT"
        Me.ConfrmBookerBTN.UseVisualStyleBackColor = False
        Me.ConfrmBookerBTN.Visible = False
        '
        'TextBox16
        '
        Me.TextBox16.Font = New System.Drawing.Font("Rockwell", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox16.Location = New System.Drawing.Point(1074, 576)
        Me.TextBox16.Multiline = True
        Me.TextBox16.Name = "TextBox16"
        Me.TextBox16.Size = New System.Drawing.Size(178, 56)
        Me.TextBox16.TabIndex = 5
        Me.TextBox16.Text = "NOW YOU CAN PAY CASH AND PRINT YOUR RECEIPT"
        Me.TextBox16.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.TextBox16.Visible = False
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.BackColor = System.Drawing.Color.Transparent
        Me.Label16.Font = New System.Drawing.Font("Algerian", 72.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.ForeColor = System.Drawing.Color.Black
        Me.Label16.Location = New System.Drawing.Point(290, 9)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(806, 106)
        Me.Label16.TabIndex = 28
        Me.Label16.Text = "USER'S  REQUEST"
        '
        'TextBox18
        '
        Me.TextBox18.Font = New System.Drawing.Font("Rockwell", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox18.Location = New System.Drawing.Point(1090, 654)
        Me.TextBox18.Multiline = True
        Me.TextBox18.Name = "TextBox18"
        Me.TextBox18.ReadOnly = True
        Me.TextBox18.Size = New System.Drawing.Size(196, 54)
        Me.TextBox18.TabIndex = 29
        Me.TextBox18.Text = "THE REQUEST IS DENIED" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "SORRY" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.TextBox18.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.TextBox18.Visible = False
        '
        'DenyBTN
        '
        Me.DenyBTN.BackColor = System.Drawing.Color.Black
        Me.DenyBTN.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.DenyBTN.Font = New System.Drawing.Font("Algerian", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DenyBTN.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.DenyBTN.Location = New System.Drawing.Point(1043, 488)
        Me.DenyBTN.Name = "DenyBTN"
        Me.DenyBTN.Size = New System.Drawing.Size(209, 65)
        Me.DenyBTN.TabIndex = 30
        Me.DenyBTN.Text = "DENY RENT"
        Me.DenyBTN.UseVisualStyleBackColor = False
        Me.DenyBTN.Visible = False
        '
        'PictureBoxBooker
        '
        Me.PictureBoxBooker.BackColor = System.Drawing.Color.Transparent
        Me.PictureBoxBooker.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PictureBoxBooker.Location = New System.Drawing.Point(218, 355)
        Me.PictureBoxBooker.Name = "PictureBoxBooker"
        Me.PictureBoxBooker.Size = New System.Drawing.Size(496, 353)
        Me.PictureBoxBooker.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBoxBooker.TabIndex = 4
        Me.PictureBoxBooker.TabStop = False
        '
        'RadioButton4
        '
        Me.RadioButton4.AutoSize = True
        Me.RadioButton4.Font = New System.Drawing.Font("Imprint MT Shadow", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RadioButton4.Location = New System.Drawing.Point(1095, 503)
        Me.RadioButton4.Name = "RadioButton4"
        Me.RadioButton4.Size = New System.Drawing.Size(126, 32)
        Me.RadioButton4.TabIndex = 36
        Me.RadioButton4.TabStop = True
        Me.RadioButton4.Text = "Available"
        Me.RadioButton4.UseVisualStyleBackColor = True
        '
        'RadioButton3
        '
        Me.RadioButton3.AutoSize = True
        Me.RadioButton3.Font = New System.Drawing.Font("Imprint MT Shadow", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RadioButton3.Location = New System.Drawing.Point(945, 503)
        Me.RadioButton3.Name = "RadioButton3"
        Me.RadioButton3.Size = New System.Drawing.Size(143, 32)
        Me.RadioButton3.TabIndex = 35
        Me.RadioButton3.TabStop = True
        Me.RadioButton3.Text = "Unvailable"
        Me.RadioButton3.UseVisualStyleBackColor = True
        '
        'UpdateStatusBTN
        '
        Me.UpdateStatusBTN.BackColor = System.Drawing.Color.Black
        Me.UpdateStatusBTN.Enabled = False
        Me.UpdateStatusBTN.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.UpdateStatusBTN.Font = New System.Drawing.Font("Algerian", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UpdateStatusBTN.ForeColor = System.Drawing.SystemColors.ControlLight
        Me.UpdateStatusBTN.Location = New System.Drawing.Point(735, 488)
        Me.UpdateStatusBTN.Name = "UpdateStatusBTN"
        Me.UpdateStatusBTN.Size = New System.Drawing.Size(209, 65)
        Me.UpdateStatusBTN.TabIndex = 37
        Me.UpdateStatusBTN.Text = "UPDATE " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "CAR STATUS"
        Me.UpdateStatusBTN.UseVisualStyleBackColor = False
        '
        'TCodeBTN
        '
        Me.TCodeBTN.BackColor = System.Drawing.Color.White
        Me.TCodeBTN.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.TCodeBTN.Font = New System.Drawing.Font("Haettenschweiler", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TCodeBTN.Location = New System.Drawing.Point(945, 437)
        Me.TCodeBTN.Name = "TCodeBTN"
        Me.TCodeBTN.Size = New System.Drawing.Size(135, 29)
        Me.TCodeBTN.TabIndex = 39
        Me.TCodeBTN.Text = "TCode"
        Me.TCodeBTN.UseVisualStyleBackColor = False
        '
        'TextBoxTcode
        '
        Me.TextBoxTcode.BackColor = System.Drawing.Color.Black
        Me.TextBoxTcode.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxTcode.ForeColor = System.Drawing.Color.White
        Me.TextBoxTcode.Location = New System.Drawing.Point(919, 375)
        Me.TextBoxTcode.Multiline = True
        Me.TextBoxTcode.Name = "TextBoxTcode"
        Me.TextBoxTcode.Size = New System.Drawing.Size(176, 56)
        Me.TextBoxTcode.TabIndex = 40
        Me.TextBoxTcode.TabStop = False
        Me.TextBoxTcode.Text = "PRESS Tcode Button to CREATE A TRANSACTION CODE"
        Me.TextBoxTcode.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBoxCampanyNa
        '
        Me.TextBoxCampanyNa.Location = New System.Drawing.Point(906, 585)
        Me.TextBoxCampanyNa.Name = "TextBoxCampanyNa"
        Me.TextBoxCampanyNa.Size = New System.Drawing.Size(131, 20)
        Me.TextBoxCampanyNa.TabIndex = 41
        Me.TextBoxCampanyNa.Visible = False
        '
        'TextBoxContactN
        '
        Me.TextBoxContactN.Location = New System.Drawing.Point(906, 611)
        Me.TextBoxContactN.Name = "TextBoxContactN"
        Me.TextBoxContactN.Size = New System.Drawing.Size(131, 20)
        Me.TextBoxContactN.TabIndex = 42
        Me.TextBoxContactN.Visible = False
        '
        'TextBoxEmail
        '
        Me.TextBoxEmail.Location = New System.Drawing.Point(906, 635)
        Me.TextBoxEmail.Name = "TextBoxEmail"
        Me.TextBoxEmail.Size = New System.Drawing.Size(131, 20)
        Me.TextBoxEmail.TabIndex = 43
        Me.TextBoxEmail.Visible = False
        '
        'TextBoxLocation
        '
        Me.TextBoxLocation.Location = New System.Drawing.Point(906, 661)
        Me.TextBoxLocation.Name = "TextBoxLocation"
        Me.TextBoxLocation.Size = New System.Drawing.Size(131, 20)
        Me.TextBoxLocation.TabIndex = 44
        Me.TextBoxLocation.Visible = False
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.BackColor = System.Drawing.Color.Black
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.ForeColor = System.Drawing.Color.White
        Me.Label17.Location = New System.Drawing.Point(775, 666)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(88, 18)
        Me.Label17.TabIndex = 51
        Me.Label17.Text = "Location  :"
        Me.Label17.Visible = False
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.BackColor = System.Drawing.Color.Black
        Me.Label20.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.ForeColor = System.Drawing.Color.White
        Me.Label20.Location = New System.Drawing.Point(772, 611)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(99, 18)
        Me.Label20.TabIndex = 49
        Me.Label20.Text = "ContactNo :"
        Me.Label20.Visible = False
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.BackColor = System.Drawing.Color.Black
        Me.Label21.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.ForeColor = System.Drawing.Color.White
        Me.Label21.Location = New System.Drawing.Point(772, 637)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(60, 18)
        Me.Label21.TabIndex = 50
        Me.Label21.Text = "Email :"
        Me.Label21.Visible = False
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.BackColor = System.Drawing.Color.Black
        Me.Label22.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.ForeColor = System.Drawing.Color.White
        Me.Label22.Location = New System.Drawing.Point(772, 583)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(132, 18)
        Me.Label22.TabIndex = 48
        Me.Label22.Text = "CampanyName :"
        Me.Label22.Visible = False
        '
        'CheckForBooker
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.DimGray
        Me.BackgroundImage = Global.CAR_RENTING_SYSTEM.My.Resources.Resources.GTTY67
        Me.ClientSize = New System.Drawing.Size(1370, 749)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.Label20)
        Me.Controls.Add(Me.Label21)
        Me.Controls.Add(Me.Label22)
        Me.Controls.Add(Me.TextBoxEmail)
        Me.Controls.Add(Me.TextBoxLocation)
        Me.Controls.Add(Me.RadioButton3)
        Me.Controls.Add(Me.TextBoxCampanyNa)
        Me.Controls.Add(Me.RadioButton4)
        Me.Controls.Add(Me.TextBoxContactN)
        Me.Controls.Add(Me.UpdateStatusBTN)
        Me.Controls.Add(Me.TextBoxTcode)
        Me.Controls.Add(Me.TCodeBTN)
        Me.Controls.Add(Me.DenyBTN)
        Me.Controls.Add(Me.ConfrmBookerBTN)
        Me.Controls.Add(Me.TextBox18)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.TextBox16)
        Me.Controls.Add(Me.PictureBoxBooker)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "CheckForBooker"
        Me.Text = "Checkbooker"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.PictureBoxBooker, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents BackgroundWorker1 As System.ComponentModel.BackgroundWorker
    Friend WithEvents TextBoxContactNumber As TextBox
    Friend WithEvents TextBoxUsername As TextBox
    Friend WithEvents TextBoxSurname As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents TextBoxFirstname As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents TextBoxPircePerDay As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents TextBoxIDNumber As TextBox
    Friend WithEvents TextBoxPlateNumber As TextBox
    Friend WithEvents TextBoxYearofMaker As TextBox
    Friend WithEvents Label11 As Label
    Friend WithEvents TextBoxManufacture As TextBox
    Friend WithEvents TextBoxColor As TextBox
    Friend WithEvents TextBoxModel As TextBox
    Friend WithEvents TextBoxRentWithDriver As TextBox
    Friend WithEvents TextBox12 As TextBox
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents TextBoxNumberOfDay As TextBox
    Friend WithEvents TextBoxDateOfRent As TextBox
    Friend WithEvents Label15 As Label
    Friend WithEvents ConfrmBookerBTN As Button
    Friend WithEvents PictureBoxBooker As PictureBox
    Friend WithEvents TextBox16 As TextBox
    Friend WithEvents TextBoxSubTotalPrice As TextBox
    Friend WithEvents Label16 As Label
    Friend WithEvents TextBox18 As TextBox
    Friend WithEvents DenyBTN As Button
    Friend WithEvents RadioButton4 As RadioButton
    Friend WithEvents RadioButton3 As RadioButton
    Friend WithEvents UpdateStatusBTN As Button
    Friend WithEvents TCodeBTN As Button
    Friend WithEvents TextBoxTcode As TextBox
    Friend WithEvents TextBoxDiscount As TextBox
    Friend WithEvents TextBoxTotolPric As TextBox
    Friend WithEvents Discount As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents TextBoxCampanyNa As TextBox
    Friend WithEvents TextBoxContactN As TextBox
    Friend WithEvents TextBoxEmail As TextBox
    Friend WithEvents TextBoxLocation As TextBox
    Friend WithEvents Label17 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents Label21 As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents TextBoxDateOfReturn As TextBox
    Friend WithEvents Label23 As Label
End Class
