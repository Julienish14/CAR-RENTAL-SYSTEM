﻿Public Class Book
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles CheckcarBTN.Click
        Cars.Show()
        Me.Hide()
    End Sub

    Private Sub Book_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.MaximizeBox = False
        Me.Text = "CUSTOMER INFORMATION"
    End Sub
End Class