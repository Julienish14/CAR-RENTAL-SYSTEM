﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class AdminCars
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(AdminCars))
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.AddCarSAVEBtn = New System.Windows.Forms.Button()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.RadioButton3 = New System.Windows.Forms.RadioButton()
        Me.RadioButton4UPDATE = New System.Windows.Forms.RadioButton()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.TextBox6 = New System.Windows.Forms.TextBox()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        Me.RadioButton2 = New System.Windows.Forms.RadioButton()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.RadioButton1 = New System.Windows.Forms.RadioButton()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.AddnewCarBTN = New System.Windows.Forms.Button()
        Me.DeletcarBTN = New System.Windows.Forms.Button()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.uploadCaPicBTN = New System.Windows.Forms.Button()
        Me.RadioButton5CarstatusSAVE = New System.Windows.Forms.RadioButton()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.PlateNumberDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ManufactureDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ModelDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ColorDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.YearOfMakerDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PricePerDayDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ImageDataGridViewImageColumn = New System.Windows.Forms.DataGridViewImageColumn()
        Me.DateAdmittedDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CarTransmissionDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CarStatusDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CarinformationBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.CAR_RENTING_SYSTEM_DBDataSet10 = New CAR_RENTING_SYSTEM.CAR_RENTING_SYSTEM_DBDataSet10()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.ADDUPDATEBTN = New System.Windows.Forms.Button()
        Me.RadioButton6UPDATEUnvailable = New System.Windows.Forms.RadioButton()
        Me.GroupBox8 = New System.Windows.Forms.GroupBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.CarinformationTableAdapter = New CAR_RENTING_SYSTEM.CAR_RENTING_SYSTEM_DBDataSet10TableAdapters.CarinformationTableAdapter()
        Me.TextBox7 = New System.Windows.Forms.TextBox()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox4.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CarinformationBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CAR_RENTING_SYSTEM_DBDataSet10, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox8.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox1.Controls.Add(Me.AddCarSAVEBtn)
        Me.GroupBox1.Controls.Add(Me.GroupBox2)
        Me.GroupBox1.Controls.Add(Me.PictureBox1)
        Me.GroupBox1.Controls.Add(Me.AddnewCarBTN)
        Me.GroupBox1.Controls.Add(Me.DeletcarBTN)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.uploadCaPicBTN)
        Me.GroupBox1.Font = New System.Drawing.Font("Rockwell", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(117, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(1191, 444)
        Me.GroupBox1.TabIndex = 1
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "ADD CAR INFORMATION"
        '
        'AddCarSAVEBtn
        '
        Me.AddCarSAVEBtn.BackColor = System.Drawing.Color.Black
        Me.AddCarSAVEBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.AddCarSAVEBtn.Font = New System.Drawing.Font("Algerian", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddCarSAVEBtn.ForeColor = System.Drawing.Color.White
        Me.AddCarSAVEBtn.Location = New System.Drawing.Point(928, 347)
        Me.AddCarSAVEBtn.Name = "AddCarSAVEBtn"
        Me.AddCarSAVEBtn.Size = New System.Drawing.Size(237, 91)
        Me.AddCarSAVEBtn.TabIndex = 3
        Me.AddCarSAVEBtn.Text = "SAVE"
        Me.AddCarSAVEBtn.UseVisualStyleBackColor = False
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.Black
        Me.GroupBox2.Controls.Add(Me.GroupBox3)
        Me.GroupBox2.Controls.Add(Me.DateTimePicker1)
        Me.GroupBox2.Controls.Add(Me.Label8)
        Me.GroupBox2.Controls.Add(Me.TextBox6)
        Me.GroupBox2.Controls.Add(Me.TextBox5)
        Me.GroupBox2.Controls.Add(Me.RadioButton2)
        Me.GroupBox2.Controls.Add(Me.TextBox4)
        Me.GroupBox2.Controls.Add(Me.TextBox3)
        Me.GroupBox2.Controls.Add(Me.TextBox2)
        Me.GroupBox2.Controls.Add(Me.Label2)
        Me.GroupBox2.Controls.Add(Me.RadioButton1)
        Me.GroupBox2.Controls.Add(Me.Label1)
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Controls.Add(Me.Label3)
        Me.GroupBox2.Controls.Add(Me.Label4)
        Me.GroupBox2.Controls.Add(Me.Label5)
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Controls.Add(Me.TextBox1)
        Me.GroupBox2.Font = New System.Drawing.Font("Rockwell", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.ForeColor = System.Drawing.Color.White
        Me.GroupBox2.Location = New System.Drawing.Point(515, 138)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(670, 190)
        Me.GroupBox2.TabIndex = 2
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Full Info For New Car"
        '
        'GroupBox3
        '
        Me.GroupBox3.BackColor = System.Drawing.Color.DimGray
        Me.GroupBox3.Controls.Add(Me.RadioButton3)
        Me.GroupBox3.Controls.Add(Me.RadioButton4UPDATE)
        Me.GroupBox3.Controls.Add(Me.Label10)
        Me.GroupBox3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.GroupBox3.Location = New System.Drawing.Point(309, 123)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(355, 59)
        Me.GroupBox3.TabIndex = 76
        Me.GroupBox3.TabStop = False
        '
        'RadioButton3
        '
        Me.RadioButton3.AutoSize = True
        Me.RadioButton3.Font = New System.Drawing.Font("Rockwell", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RadioButton3.Location = New System.Drawing.Point(124, 21)
        Me.RadioButton3.Name = "RadioButton3"
        Me.RadioButton3.Size = New System.Drawing.Size(102, 23)
        Me.RadioButton3.TabIndex = 77
        Me.RadioButton3.Text = "Available"
        Me.RadioButton3.UseVisualStyleBackColor = True
        '
        'RadioButton4UPDATE
        '
        Me.RadioButton4UPDATE.AutoSize = True
        Me.RadioButton4UPDATE.Font = New System.Drawing.Font("Rockwell", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RadioButton4UPDATE.ForeColor = System.Drawing.Color.Black
        Me.RadioButton4UPDATE.Location = New System.Drawing.Point(229, 23)
        Me.RadioButton4UPDATE.Name = "RadioButton4UPDATE"
        Me.RadioButton4UPDATE.Size = New System.Drawing.Size(112, 23)
        Me.RadioButton4UPDATE.TabIndex = 78
        Me.RadioButton4UPDATE.Text = "Unvailable"
        Me.RadioButton4UPDATE.UseVisualStyleBackColor = True
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Rockwell", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(6, 21)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(100, 19)
        Me.Label10.TabIndex = 79
        Me.Label10.Text = "Car Status :"
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.CustomFormat = "dd,MM,yyyy"
        Me.DateTimePicker1.Font = New System.Drawing.Font("Rockwell", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.DateTimePicker1.Location = New System.Drawing.Point(433, 53)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(114, 26)
        Me.DateTimePicker1.TabIndex = 68
        Me.DateTimePicker1.Visible = False
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Rockwell", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(304, 57)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(134, 19)
        Me.Label8.TabIndex = 67
        Me.Label8.Text = "Date Admitted :"
        Me.Label8.Visible = False
        '
        'TextBox6
        '
        Me.TextBox6.Font = New System.Drawing.Font("Rockwell", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox6.Location = New System.Drawing.Point(432, 56)
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.Size = New System.Drawing.Size(114, 26)
        Me.TextBox6.TabIndex = 61
        '
        'TextBox5
        '
        Me.TextBox5.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox5.Location = New System.Drawing.Point(138, 160)
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.Size = New System.Drawing.Size(159, 24)
        Me.TextBox5.TabIndex = 60
        '
        'RadioButton2
        '
        Me.RadioButton2.AutoSize = True
        Me.RadioButton2.Font = New System.Drawing.Font("Rockwell", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RadioButton2.Location = New System.Drawing.Point(552, 103)
        Me.RadioButton2.Name = "RadioButton2"
        Me.RadioButton2.Size = New System.Drawing.Size(109, 23)
        Me.RadioButton2.TabIndex = 75
        Me.RadioButton2.TabStop = True
        Me.RadioButton2.Text = "Automatic"
        Me.RadioButton2.UseVisualStyleBackColor = True
        '
        'TextBox4
        '
        Me.TextBox4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox4.Location = New System.Drawing.Point(138, 133)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(159, 22)
        Me.TextBox4.TabIndex = 59
        '
        'TextBox3
        '
        Me.TextBox3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox3.Location = New System.Drawing.Point(138, 102)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(159, 22)
        Me.TextBox3.TabIndex = 58
        '
        'TextBox2
        '
        Me.TextBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox2.Location = New System.Drawing.Point(140, 70)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(157, 22)
        Me.TextBox2.TabIndex = 57
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Rockwell", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(6, 70)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(128, 19)
        Me.Label2.TabIndex = 51
        Me.Label2.Text = "Manufacturer :"
        '
        'RadioButton1
        '
        Me.RadioButton1.AutoSize = True
        Me.RadioButton1.Font = New System.Drawing.Font("Rockwell", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RadioButton1.Location = New System.Drawing.Point(469, 103)
        Me.RadioButton1.Name = "RadioButton1"
        Me.RadioButton1.Size = New System.Drawing.Size(88, 23)
        Me.RadioButton1.TabIndex = 74
        Me.RadioButton1.TabStop = True
        Me.RadioButton1.Text = "Manual"
        Me.RadioButton1.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Rockwell", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(8, 33)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(129, 19)
        Me.Label1.TabIndex = 50
        Me.Label1.Text = "Plate Number :"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Rockwell", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(303, 103)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(160, 19)
        Me.Label7.TabIndex = 73
        Me.Label7.Text = "Car Transmission :"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Rockwell", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(8, 103)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(121, 19)
        Me.Label3.TabIndex = 52
        Me.Label3.Text = "Model Name :"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Rockwell", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(6, 134)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(63, 19)
        Me.Label4.TabIndex = 53
        Me.Label4.Text = "Color :"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Rockwell", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(4, 163)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(130, 19)
        Me.Label5.TabIndex = 54
        Me.Label5.Text = "Year of Maker :"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Rockwell", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(304, 59)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(128, 19)
        Me.Label6.TabIndex = 55
        Me.Label6.Text = "Price Per Day :"
        '
        'TextBox1
        '
        Me.TextBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox1.Location = New System.Drawing.Point(140, 32)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(157, 22)
        Me.TextBox1.TabIndex = 56
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PictureBox1.Location = New System.Drawing.Point(6, 21)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(490, 378)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'AddnewCarBTN
        '
        Me.AddnewCarBTN.BackColor = System.Drawing.Color.SlateGray
        Me.AddnewCarBTN.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.AddnewCarBTN.Font = New System.Drawing.Font("Algerian", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddnewCarBTN.Location = New System.Drawing.Point(948, 385)
        Me.AddnewCarBTN.Name = "AddnewCarBTN"
        Me.AddnewCarBTN.Size = New System.Drawing.Size(185, 45)
        Me.AddnewCarBTN.TabIndex = 67
        Me.AddnewCarBTN.Text = "ADD NEW CAR"
        Me.AddnewCarBTN.UseVisualStyleBackColor = False
        Me.AddnewCarBTN.Visible = False
        '
        'DeletcarBTN
        '
        Me.DeletcarBTN.BackColor = System.Drawing.Color.SlateGray
        Me.DeletcarBTN.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.DeletcarBTN.Font = New System.Drawing.Font("Algerian", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DeletcarBTN.ForeColor = System.Drawing.Color.Black
        Me.DeletcarBTN.Location = New System.Drawing.Point(515, 385)
        Me.DeletcarBTN.Name = "DeletcarBTN"
        Me.DeletcarBTN.Size = New System.Drawing.Size(249, 49)
        Me.DeletcarBTN.TabIndex = 3
        Me.DeletcarBTN.Text = "DELETE CAR"
        Me.DeletcarBTN.UseVisualStyleBackColor = False
        Me.DeletcarBTN.Visible = False
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Algerian", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.White
        Me.Label9.Location = New System.Drawing.Point(646, 21)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(343, 108)
        Me.Label9.TabIndex = 4
        Me.Label9.Text = "ADD NEW CAR" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " IN SYSTEM"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'uploadCaPicBTN
        '
        Me.uploadCaPicBTN.BackColor = System.Drawing.Color.Black
        Me.uploadCaPicBTN.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uploadCaPicBTN.ForeColor = System.Drawing.Color.White
        Me.uploadCaPicBTN.Location = New System.Drawing.Point(0, 405)
        Me.uploadCaPicBTN.Name = "uploadCaPicBTN"
        Me.uploadCaPicBTN.Size = New System.Drawing.Size(171, 29)
        Me.uploadCaPicBTN.TabIndex = 2
        Me.uploadCaPicBTN.Text = "Upload Car Picture"
        Me.uploadCaPicBTN.UseVisualStyleBackColor = False
        '
        'RadioButton5CarstatusSAVE
        '
        Me.RadioButton5CarstatusSAVE.AutoSize = True
        Me.RadioButton5CarstatusSAVE.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RadioButton5CarstatusSAVE.ForeColor = System.Drawing.Color.Transparent
        Me.RadioButton5CarstatusSAVE.Location = New System.Drawing.Point(38, 91)
        Me.RadioButton5CarstatusSAVE.Name = "RadioButton5CarstatusSAVE"
        Me.RadioButton5CarstatusSAVE.Size = New System.Drawing.Size(110, 24)
        Me.RadioButton5CarstatusSAVE.TabIndex = 69
        Me.RadioButton5CarstatusSAVE.Text = "Unvailable"
        Me.RadioButton5CarstatusSAVE.UseVisualStyleBackColor = True
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.DataGridView1)
        Me.GroupBox4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox4.Location = New System.Drawing.Point(12, 452)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(1141, 227)
        Me.GroupBox4.TabIndex = 2
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "CARS INFORMATION"
        '
        'DataGridView1
        '
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.PlateNumberDataGridViewTextBoxColumn, Me.ManufactureDataGridViewTextBoxColumn, Me.ModelDataGridViewTextBoxColumn, Me.ColorDataGridViewTextBoxColumn, Me.YearOfMakerDataGridViewTextBoxColumn, Me.PricePerDayDataGridViewTextBoxColumn, Me.ImageDataGridViewImageColumn, Me.DateAdmittedDataGridViewTextBoxColumn, Me.CarTransmissionDataGridViewTextBoxColumn, Me.CarStatusDataGridViewTextBoxColumn})
        Me.DataGridView1.DataSource = Me.CarinformationBindingSource
        Me.DataGridView1.Location = New System.Drawing.Point(6, 21)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(1129, 200)
        Me.DataGridView1.TabIndex = 0
        '
        'PlateNumberDataGridViewTextBoxColumn
        '
        Me.PlateNumberDataGridViewTextBoxColumn.DataPropertyName = "PlateNumber"
        Me.PlateNumberDataGridViewTextBoxColumn.HeaderText = "PlateNumber"
        Me.PlateNumberDataGridViewTextBoxColumn.Name = "PlateNumberDataGridViewTextBoxColumn"
        Me.PlateNumberDataGridViewTextBoxColumn.Width = 140
        '
        'ManufactureDataGridViewTextBoxColumn
        '
        Me.ManufactureDataGridViewTextBoxColumn.DataPropertyName = "Manufacture"
        Me.ManufactureDataGridViewTextBoxColumn.HeaderText = "Manufacture"
        Me.ManufactureDataGridViewTextBoxColumn.Name = "ManufactureDataGridViewTextBoxColumn"
        Me.ManufactureDataGridViewTextBoxColumn.Width = 140
        '
        'ModelDataGridViewTextBoxColumn
        '
        Me.ModelDataGridViewTextBoxColumn.DataPropertyName = "Model"
        Me.ModelDataGridViewTextBoxColumn.HeaderText = "Model"
        Me.ModelDataGridViewTextBoxColumn.Name = "ModelDataGridViewTextBoxColumn"
        Me.ModelDataGridViewTextBoxColumn.Width = 140
        '
        'ColorDataGridViewTextBoxColumn
        '
        Me.ColorDataGridViewTextBoxColumn.DataPropertyName = "Color"
        Me.ColorDataGridViewTextBoxColumn.HeaderText = "Color"
        Me.ColorDataGridViewTextBoxColumn.Name = "ColorDataGridViewTextBoxColumn"
        '
        'YearOfMakerDataGridViewTextBoxColumn
        '
        Me.YearOfMakerDataGridViewTextBoxColumn.DataPropertyName = "YearOfMaker"
        Me.YearOfMakerDataGridViewTextBoxColumn.HeaderText = "YearOfMaker"
        Me.YearOfMakerDataGridViewTextBoxColumn.Name = "YearOfMakerDataGridViewTextBoxColumn"
        Me.YearOfMakerDataGridViewTextBoxColumn.Width = 110
        '
        'PricePerDayDataGridViewTextBoxColumn
        '
        Me.PricePerDayDataGridViewTextBoxColumn.DataPropertyName = "PricePerDay"
        Me.PricePerDayDataGridViewTextBoxColumn.HeaderText = "PricePerDay"
        Me.PricePerDayDataGridViewTextBoxColumn.Name = "PricePerDayDataGridViewTextBoxColumn"
        Me.PricePerDayDataGridViewTextBoxColumn.Width = 110
        '
        'ImageDataGridViewImageColumn
        '
        Me.ImageDataGridViewImageColumn.DataPropertyName = "Image"
        Me.ImageDataGridViewImageColumn.HeaderText = "Image"
        Me.ImageDataGridViewImageColumn.Name = "ImageDataGridViewImageColumn"
        Me.ImageDataGridViewImageColumn.Visible = False
        '
        'DateAdmittedDataGridViewTextBoxColumn
        '
        Me.DateAdmittedDataGridViewTextBoxColumn.DataPropertyName = "DateAdmitted"
        Me.DateAdmittedDataGridViewTextBoxColumn.HeaderText = "DateAdmitted"
        Me.DateAdmittedDataGridViewTextBoxColumn.Name = "DateAdmittedDataGridViewTextBoxColumn"
        Me.DateAdmittedDataGridViewTextBoxColumn.Width = 120
        '
        'CarTransmissionDataGridViewTextBoxColumn
        '
        Me.CarTransmissionDataGridViewTextBoxColumn.DataPropertyName = "CarTransmission"
        Me.CarTransmissionDataGridViewTextBoxColumn.HeaderText = "CarTransmission"
        Me.CarTransmissionDataGridViewTextBoxColumn.Name = "CarTransmissionDataGridViewTextBoxColumn"
        Me.CarTransmissionDataGridViewTextBoxColumn.Width = 130
        '
        'CarStatusDataGridViewTextBoxColumn
        '
        Me.CarStatusDataGridViewTextBoxColumn.DataPropertyName = "CarStatus"
        Me.CarStatusDataGridViewTextBoxColumn.HeaderText = "CarStatus"
        Me.CarStatusDataGridViewTextBoxColumn.Name = "CarStatusDataGridViewTextBoxColumn"
        Me.CarStatusDataGridViewTextBoxColumn.Width = 130
        '
        'CarinformationBindingSource
        '
        Me.CarinformationBindingSource.DataMember = "Carinformation"
        Me.CarinformationBindingSource.DataSource = Me.CAR_RENTING_SYSTEM_DBDataSet10
        '
        'CAR_RENTING_SYSTEM_DBDataSet10
        '
        Me.CAR_RENTING_SYSTEM_DBDataSet10.DataSetName = "CAR_RENTING_SYSTEM_DBDataSet10"
        Me.CAR_RENTING_SYSTEM_DBDataSet10.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'ADDUPDATEBTN
        '
        Me.ADDUPDATEBTN.BackColor = System.Drawing.Color.Transparent
        Me.ADDUPDATEBTN.Enabled = False
        Me.ADDUPDATEBTN.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ADDUPDATEBTN.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ADDUPDATEBTN.ForeColor = System.Drawing.SystemColors.ControlLight
        Me.ADDUPDATEBTN.Location = New System.Drawing.Point(27, 121)
        Me.ADDUPDATEBTN.Name = "ADDUPDATEBTN"
        Me.ADDUPDATEBTN.Size = New System.Drawing.Size(125, 51)
        Me.ADDUPDATEBTN.TabIndex = 38
        Me.ADDUPDATEBTN.Text = "UPDATE "
        Me.ADDUPDATEBTN.UseVisualStyleBackColor = False
        '
        'RadioButton6UPDATEUnvailable
        '
        Me.RadioButton6UPDATEUnvailable.AutoSize = True
        Me.RadioButton6UPDATEUnvailable.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RadioButton6UPDATEUnvailable.ForeColor = System.Drawing.Color.Transparent
        Me.RadioButton6UPDATEUnvailable.Location = New System.Drawing.Point(38, 57)
        Me.RadioButton6UPDATEUnvailable.Name = "RadioButton6UPDATEUnvailable"
        Me.RadioButton6UPDATEUnvailable.Size = New System.Drawing.Size(113, 28)
        Me.RadioButton6UPDATEUnvailable.TabIndex = 70
        Me.RadioButton6UPDATEUnvailable.Text = "Available"
        Me.RadioButton6UPDATEUnvailable.UseVisualStyleBackColor = True
        '
        'GroupBox8
        '
        Me.GroupBox8.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox8.Controls.Add(Me.Label11)
        Me.GroupBox8.Controls.Add(Me.RadioButton5CarstatusSAVE)
        Me.GroupBox8.Controls.Add(Me.RadioButton6UPDATEUnvailable)
        Me.GroupBox8.Controls.Add(Me.ADDUPDATEBTN)
        Me.GroupBox8.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox8.ForeColor = System.Drawing.Color.White
        Me.GroupBox8.Location = New System.Drawing.Point(1153, 501)
        Me.GroupBox8.Name = "GroupBox8"
        Me.GroupBox8.Size = New System.Drawing.Size(179, 178)
        Me.GroupBox8.TabIndex = 5
        Me.GroupBox8.TabStop = False
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(6, 18)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(171, 36)
        Me.Label11.TabIndex = 71
        Me.Label11.Text = "UPDATE RETURNED" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "CAR STATUS"
        Me.Label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'CarinformationTableAdapter
        '
        Me.CarinformationTableAdapter.ClearBeforeFill = True
        '
        'TextBox7
        '
        Me.TextBox7.BackColor = System.Drawing.Color.Black
        Me.TextBox7.Font = New System.Drawing.Font("Lucida Bright", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox7.ForeColor = System.Drawing.Color.White
        Me.TextBox7.Location = New System.Drawing.Point(1153, 462)
        Me.TextBox7.Multiline = True
        Me.TextBox7.Name = "TextBox7"
        Me.TextBox7.Size = New System.Drawing.Size(168, 42)
        Me.TextBox7.TabIndex = 6
        Me.TextBox7.TabStop = False
        Me.TextBox7.Text = "False = Available" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "True = Unvailable"
        Me.TextBox7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'AdminCars
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.CAR_RENTING_SYSTEM.My.Resources.Resources.GRTTYIMAGE21
        Me.ClientSize = New System.Drawing.Size(1370, 749)
        Me.Controls.Add(Me.TextBox7)
        Me.Controls.Add(Me.GroupBox8)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "AdminCars"
        Me.Text = "AdminCars"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox4.ResumeLayout(False)
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CarinformationBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CAR_RENTING_SYSTEM_DBDataSet10, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox8.ResumeLayout(False)
        Me.GroupBox8.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents AddCarSAVEBtn As Button
    Friend WithEvents uploadCaPicBTN As Button
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents DeletcarBTN As Button
    Friend WithEvents OpenFileDialog1 As OpenFileDialog
    Friend WithEvents Label9 As Label
    Friend WithEvents CarinformationBindingSource1 As BindingSource
    Friend WithEvents ADDUPDATEBTN As Button
    Friend WithEvents RadioButton6UPDATEUnvailable As RadioButton
    Friend WithEvents RadioButton5CarstatusSAVE As RadioButton
    Friend WithEvents GroupBox8 As GroupBox
    Friend WithEvents Label11 As Label
    Friend WithEvents AddnewCarBTN As Button
    Friend WithEvents CarinformationTableAdapter1 As CAR_RENTING_SYSTEM_DBDataSet9TableAdapters.CarinformationTableAdapter
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents CAR_RENTING_SYSTEM_DBDataSet10 As CAR_RENTING_SYSTEM_DBDataSet10
    Friend WithEvents CarinformationBindingSource As BindingSource
    Friend WithEvents CarinformationTableAdapter As CAR_RENTING_SYSTEM_DBDataSet10TableAdapters.CarinformationTableAdapter
    Friend WithEvents TextBox7 As TextBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents DateTimePicker1 As DateTimePicker
    Friend WithEvents Label8 As Label
    Friend WithEvents TextBox6 As TextBox
    Friend WithEvents TextBox5 As TextBox
    Friend WithEvents TextBox4 As TextBox
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents RadioButton2 As RadioButton
    Friend WithEvents RadioButton1 As RadioButton
    Friend WithEvents Label7 As Label
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents RadioButton3 As RadioButton
    Friend WithEvents RadioButton4UPDATE As RadioButton
    Friend WithEvents Label10 As Label
    Friend WithEvents PlateNumberDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents ManufactureDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents ModelDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents ColorDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents YearOfMakerDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents PricePerDayDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents ImageDataGridViewImageColumn As DataGridViewImageColumn
    Friend WithEvents DateAdmittedDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents CarTransmissionDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents CarStatusDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
End Class
