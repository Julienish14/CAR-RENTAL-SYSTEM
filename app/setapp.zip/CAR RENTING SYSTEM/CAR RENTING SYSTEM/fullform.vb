﻿Imports System.ComponentModel
Imports System.Data.SqlClient
Public Class fullform
    Dim connection As New SqlConnection("server = DESKTOP-N7870M5;Database= CAR RENTING SYSTEM DB; integrated security= true")

    Dim table As New DataTable()

    Private Sub BookBTN_Click(sender As Object, e As EventArgs) Handles BookBTN.Click

        If ComboBox1.Text = String.Empty And TxtboxNumberofday.Text = String.Empty Then
            MsgBox("FILL INFORMATION TO REQUEST A CAR ", MsgBoxStyle.Critical, "ERROR")

        ElseIf ComboBox1.Text = String.Empty Then
            MsgBox("CHOSE FOR RENT WITH DRIVER OR NOT", MsgBoxStyle.Critical, "FILL INFORMATION OF WHAT YOU WANT")
        ElseIf TxtboxNumberofday.Text = String.Empty Then
            MsgBox("FILL THE NUMBER OF DAYS YOU WANT A CAR", MsgBoxStyle.Critical, "FILL INFORMATION OF WHAT YOU WANT")
            ComboBox1.Focus()
            TxtboxNumberofday.Focus()

        Else

            If Not IsNumeric(TxtboxNumberofday.Text) Then
                ErrorProvider1.SetError(TxtboxNumberofday, "Please!! ENTER DAYS IN NUMBER ")
                TxtboxNumberofday.Focus()

            Else


                Dim command As New SqlCommand("select * from Userinformation where Username=@Username Or IDNumber =@IDNumber", connection)
            command.Parameters.Add("@Username", SqlDbType.VarChar).Value = Book.TextBox3.Text
            command.Parameters.Add("@IDNumber", SqlDbType.VarChar).Value = Book.TextBox5.Text

            Dim adapter As New SqlDataAdapter(command)
            adapter.Fill(table)

            If table.Rows.Count() <= 0 Then
                MessageBox.Show("Your UserName Or Password is Incorrect")
            Else
                MsgBox("        YOU HAVE TO WAIT A MINUTE
 ......FOR ADMIN CONFORMATION ......", MsgBoxStyle.Information, "WAIT FOR RENT CONFIRMATION")


                CheckForBooker.TextBoxFirstname.Text = table(0)(0)
                CheckForBooker.TextBoxSurname.Text = table(0)(1)
                CheckForBooker.TextBoxUsername.Text = table(0)(3)
                CheckForBooker.TextBoxContactNumber.Text = table(0)(5)
                CheckForBooker.TextBoxIDNumber.Text = table(0)(10)

                CheckForBooker.TextBoxPlateNumber.Text = Cars.TextBox1.Text
                CheckForBooker.TextBoxManufacture.Text = Cars.TextBox2.Text
                CheckForBooker.TextBoxModel.Text = Cars.TextBox3.Text
                CheckForBooker.TextBoxColor.Text = Cars.TextBox4.Text
                CheckForBooker.TextBoxYearofMaker.Text = Cars.TextBox5.Text
                CheckForBooker.TextBoxPircePerDay.Text = Cars.TextBox6.Text
                CheckForBooker.TextBox12.Text = Cars.TextBox7.Text
                CheckForBooker.TextBoxDateOfRent.Text = Cars.DateTimePicker1.Value
                CheckForBooker.PictureBoxBooker.Image = Cars.PictureBox1.Image

                CheckForBooker.TextBoxRentWithDriver.Text = ComboBox1.Text
                CheckForBooker.TextBoxNumberOfDay.Text = TxtboxNumberofday.Text

                AdminTask.NocarBookedBTN.Visible = False
                    AdminTask.CheckBooker.Visible = True
                    ErrorProvider1.Clear()

                    adminLogin.Show()
                Me.Hide()
            End If

        End If
        End If
    End Sub

    Private Sub PrintDocument1_PrintPage_1(sender As Object, e As Printing.PrintPageEventArgs) Handles PrintDocument1.PrintPage

        Dim fonter As New Font("Lucida Sans", 16, FontStyle.Regular)
        Dim fonter1 As New Font("Mangal", 30, FontStyle.Regular)
        Dim fonter2 As New Font("Lucida Sans", 18, FontStyle.Italic)
        Dim fonter3 As New Font("Impact", 18, FontStyle.Underline)
        Dim fonter4 As New Font("Lucida Sans", 18, FontStyle.Bold)


        'Title
        e.Graphics.DrawString("  CAR RENTAL RECEIPT  ", fonter1, Brushes.Black, 150, 100)

        'date and receipt number
        e.Graphics.DrawString(" ReceiptNo :" + CheckForBooker.TextBoxTcode.Text, fonter2, Brushes.Black, 560, 340)
        e.Graphics.DrawString(" Date : " + DateTimePicker1.Text, fonter2, Brushes.Black, 560, 370)

        'CAMPANY INFORMATION

        e.Graphics.DrawString(" " + CheckForBooker.TextBoxCampanyNa.Text, fonter2, Brushes.Black, 10, 280)
        e.Graphics.DrawString(" " + CheckForBooker.TextBoxContactN.Text, fonter2, Brushes.Black, 10, 310)
        e.Graphics.DrawString(" " + CheckForBooker.TextBoxEmail.Text, fonter2, Brushes.Black, 10, 340)
        e.Graphics.DrawString(" " + CheckForBooker.TextBoxLocation.Text, fonter2, Brushes.Black, 10, 370)

        'RENTER INFORMATION
        e.Graphics.DrawString("  Customer Name  :  " + CheckForBooker.TextBoxFirstname.Text & "  " & CheckForBooker.TextBoxSurname.Text, fonter, Brushes.Black, 80, 500)
        e.Graphics.DrawString("  Telephone  :         " + CheckForBooker.TextBoxContactNumber.Text, fonter, Brushes.Black, 80, 530)
        e.Graphics.DrawString("  Customer Number :  " + CheckForBooker.TextBoxIDNumber.Text, fonter, Brushes.Black, 80, 560)

        'TRANSACTION INFORMATION
        e.Graphics.DrawString("  CAR No :   " + CheckForBooker.TextBoxPlateNumber.Text, fonter, Brushes.Black, 140, 640)

        e.Graphics.DrawString("  Model :    " + CheckForBooker.TextBoxModel.Text, fonter, Brushes.Black, 140, 670)

        e.Graphics.DrawString("  With Driver :    " + CheckForBooker.TextBoxRentWithDriver.Text, fonter, Brushes.Black, 140, 700)

        e.Graphics.DrawString("  Price per day  :  " + CheckForBooker.TextBoxPircePerDay.Text, fonter, Brushes.Black, 140, 730)

        e.Graphics.DrawString("  Number of Days : " + CheckForBooker.TextBoxNumberOfDay.Text, fonter, Brushes.Black, 140, 760)



        e.Graphics.DrawString("  SubTotal  :  " + (FormatCurrency(CheckForBooker.TextBoxSubTotalPrice.Text)), fonter, Brushes.Black, 190, 810)
        e.Graphics.DrawString("  Discount :   " + CheckForBooker.TextBoxDiscount.Text, fonter, Brushes.Black, 190, 840)
        e.Graphics.DrawString("  Totalprice :  ", fonter, Brushes.Black, 190, 870)
        e.Graphics.DrawString("  " + CheckForBooker.TextBoxTotolPric.Text, fonter3, Brushes.Black, 310, 870)


        e.Graphics.DrawString(" Date to return a car : " + TextBoxDATEofRet.Text, fonter4, Brushes.Black, 10, 1070)


    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles PrintBTN.Click
        If GroupBox1.Text = " " Then
            MsgBox("Is your printer Ready?", MsgBoxStyle.Information)
        Else
            PrintPreviewDialog1.ShowDialog()
            Me.Hide()
            Form1.Show()
        End If
    End Sub

    Private Sub fullform_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.StartPosition = FormStartPosition.CenterParent
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.FormBorderStyle = FormBorderStyle.Fixed3D
        Me.Text = " FILL INFORMATION OF WHAT YOU WANT"
        Me.Hide()


    End Sub

    Private Sub OkBTN_Click(sender As Object, e As EventArgs) Handles OkBTN.Click
        MsgBox("THANK YOU FOR YOUR TIME MAY BE NEXT TIME!", MsgBoxStyle.Information, "YOU ARE NOT ALLOWED TO RENT NOW")
        Me.Close()
        userLogin.Show()
    End Sub


    Private Sub TxtboxNumberofday_TextChanged(sender As Object, e As EventArgs) Handles TxtboxNumberofday.TextChanged
        Dim a As String
        a = Val(TxtboxNumberofday.Text)
        Dim dt As Date = DateTimePicker1.Text
        TextBoxDATEofRet.Text = dt.AddDays(a)

    End Sub


End Class