﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AdminRegistration
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(AdminRegistration))
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TextBox6 = New System.Windows.Forms.TextBox()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.SubmAdminBtn = New System.Windows.Forms.Button()
        Me.DeleteAdminBTN = New System.Windows.Forms.Button()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.CampanyNameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TelephoneDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.EmailDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.LocationDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AdminNameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PasswordDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AdmininformationBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.CARRENTINGSYSTEMDBDataSet12BindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.CAR_RENTING_SYSTEM_DBDataSet12 = New CAR_RENTING_SYSTEM.CAR_RENTING_SYSTEM_DBDataSet12()
        Me.AdmininformationTableAdapter = New CAR_RENTING_SYSTEM.CAR_RENTING_SYSTEM_DBDataSet12TableAdapters.AdmininformationTableAdapter()
        Me.Addnewadmin = New System.Windows.Forms.Button()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.cancelAdminconfirmBtn = New System.Windows.Forms.Button()
        Me.loginAdmnConfimBtn = New System.Windows.Forms.Button()
        Me.TextAdminPassword = New System.Windows.Forms.TextBox()
        Me.TextboxAdmin = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.AdmininformationBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CARRENTINGSYSTEMDBDataSet12BindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CAR_RENTING_SYSTEM_DBDataSet12, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.Black
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.TextBox6)
        Me.GroupBox1.Controls.Add(Me.TextBox5)
        Me.GroupBox1.Controls.Add(Me.TextBox4)
        Me.GroupBox1.Controls.Add(Me.TextBox3)
        Me.GroupBox1.Controls.Add(Me.TextBox2)
        Me.GroupBox1.Controls.Add(Me.TextBox1)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.ForeColor = System.Drawing.Color.DarkSlateGray
        Me.GroupBox1.Location = New System.Drawing.Point(329, 85)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(395, 228)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Visible = False
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label6.Font = New System.Drawing.Font("Imprint MT Shadow", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.Azure
        Me.Label6.Location = New System.Drawing.Point(8, 196)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(107, 23)
        Me.Label6.TabIndex = 11
        Me.Label6.Text = "Password :"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label5.Font = New System.Drawing.Font("Imprint MT Shadow", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.Azure
        Me.Label5.Location = New System.Drawing.Point(8, 160)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(184, 23)
        Me.Label5.TabIndex = 10
        Me.Label5.Text = "Admin user name :"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label4.Font = New System.Drawing.Font("Imprint MT Shadow", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.Azure
        Me.Label4.Location = New System.Drawing.Point(8, 126)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(103, 23)
        Me.Label4.TabIndex = 9
        Me.Label4.Text = "Location :"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label3.Font = New System.Drawing.Font("Imprint MT Shadow", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.Azure
        Me.Label3.Location = New System.Drawing.Point(8, 92)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(76, 23)
        Me.Label3.TabIndex = 8
        Me.Label3.Text = "Email :"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label2.Font = New System.Drawing.Font("Imprint MT Shadow", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Azure
        Me.Label2.Location = New System.Drawing.Point(8, 56)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(119, 23)
        Me.Label2.TabIndex = 7
        Me.Label2.Text = "Telephone :"
        '
        'TextBox6
        '
        Me.TextBox6.BackColor = System.Drawing.Color.Black
        Me.TextBox6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox6.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox6.ForeColor = System.Drawing.Color.White
        Me.TextBox6.Location = New System.Drawing.Point(197, 196)
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.Size = New System.Drawing.Size(192, 26)
        Me.TextBox6.TabIndex = 6
        '
        'TextBox5
        '
        Me.TextBox5.BackColor = System.Drawing.Color.Black
        Me.TextBox5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox5.ForeColor = System.Drawing.Color.White
        Me.TextBox5.Location = New System.Drawing.Point(197, 160)
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.Size = New System.Drawing.Size(192, 26)
        Me.TextBox5.TabIndex = 5
        '
        'TextBox4
        '
        Me.TextBox4.BackColor = System.Drawing.Color.Black
        Me.TextBox4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox4.ForeColor = System.Drawing.Color.White
        Me.TextBox4.Location = New System.Drawing.Point(197, 126)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(192, 26)
        Me.TextBox4.TabIndex = 4
        '
        'TextBox3
        '
        Me.TextBox3.BackColor = System.Drawing.Color.Black
        Me.TextBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox3.ForeColor = System.Drawing.Color.White
        Me.TextBox3.Location = New System.Drawing.Point(197, 92)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(192, 26)
        Me.TextBox3.TabIndex = 3
        '
        'TextBox2
        '
        Me.TextBox2.BackColor = System.Drawing.Color.Black
        Me.TextBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox2.ForeColor = System.Drawing.Color.White
        Me.TextBox2.Location = New System.Drawing.Point(197, 56)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(192, 26)
        Me.TextBox2.TabIndex = 2
        '
        'TextBox1
        '
        Me.TextBox1.BackColor = System.Drawing.Color.Black
        Me.TextBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox1.ForeColor = System.Drawing.Color.White
        Me.TextBox1.Location = New System.Drawing.Point(197, 18)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(192, 26)
        Me.TextBox1.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label1.Font = New System.Drawing.Font("Imprint MT Shadow", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Azure
        Me.Label1.Location = New System.Drawing.Point(8, 19)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(169, 23)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Campany Name :"
        '
        'SubmAdminBtn
        '
        Me.SubmAdminBtn.BackColor = System.Drawing.Color.MidnightBlue
        Me.SubmAdminBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.SubmAdminBtn.Font = New System.Drawing.Font("Algerian", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SubmAdminBtn.ForeColor = System.Drawing.SystemColors.ControlText
        Me.SubmAdminBtn.Location = New System.Drawing.Point(446, 330)
        Me.SubmAdminBtn.Name = "SubmAdminBtn"
        Me.SubmAdminBtn.Size = New System.Drawing.Size(173, 34)
        Me.SubmAdminBtn.TabIndex = 1
        Me.SubmAdminBtn.Text = "Submit"
        Me.SubmAdminBtn.UseVisualStyleBackColor = False
        Me.SubmAdminBtn.Visible = False
        '
        'DeleteAdminBTN
        '
        Me.DeleteAdminBTN.BackColor = System.Drawing.Color.Black
        Me.DeleteAdminBTN.Enabled = False
        Me.DeleteAdminBTN.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.DeleteAdminBTN.Font = New System.Drawing.Font("Algerian", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DeleteAdminBTN.ForeColor = System.Drawing.Color.White
        Me.DeleteAdminBTN.Location = New System.Drawing.Point(877, 491)
        Me.DeleteAdminBTN.Name = "DeleteAdminBTN"
        Me.DeleteAdminBTN.Size = New System.Drawing.Size(139, 39)
        Me.DeleteAdminBTN.TabIndex = 2
        Me.DeleteAdminBTN.Text = "DELETE"
        Me.DeleteAdminBTN.UseVisualStyleBackColor = False
        Me.DeleteAdminBTN.Visible = False
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.Black
        Me.GroupBox2.Controls.Add(Me.DataGridView1)
        Me.GroupBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.Location = New System.Drawing.Point(88, 374)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(783, 174)
        Me.GroupBox2.TabIndex = 4
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Visible = False
        '
        'DataGridView1
        '
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.CampanyNameDataGridViewTextBoxColumn, Me.TelephoneDataGridViewTextBoxColumn, Me.EmailDataGridViewTextBoxColumn, Me.LocationDataGridViewTextBoxColumn, Me.AdminNameDataGridViewTextBoxColumn, Me.PasswordDataGridViewTextBoxColumn})
        Me.DataGridView1.DataSource = Me.AdmininformationBindingSource
        Me.DataGridView1.Location = New System.Drawing.Point(6, 12)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(771, 156)
        Me.DataGridView1.TabIndex = 0
        '
        'CampanyNameDataGridViewTextBoxColumn
        '
        Me.CampanyNameDataGridViewTextBoxColumn.DataPropertyName = "CampanyName"
        Me.CampanyNameDataGridViewTextBoxColumn.HeaderText = "CampanyName"
        Me.CampanyNameDataGridViewTextBoxColumn.Name = "CampanyNameDataGridViewTextBoxColumn"
        Me.CampanyNameDataGridViewTextBoxColumn.Width = 130
        '
        'TelephoneDataGridViewTextBoxColumn
        '
        Me.TelephoneDataGridViewTextBoxColumn.DataPropertyName = "Telephone"
        Me.TelephoneDataGridViewTextBoxColumn.HeaderText = "Telephone"
        Me.TelephoneDataGridViewTextBoxColumn.Name = "TelephoneDataGridViewTextBoxColumn"
        Me.TelephoneDataGridViewTextBoxColumn.Width = 120
        '
        'EmailDataGridViewTextBoxColumn
        '
        Me.EmailDataGridViewTextBoxColumn.DataPropertyName = "Email"
        Me.EmailDataGridViewTextBoxColumn.HeaderText = "Email"
        Me.EmailDataGridViewTextBoxColumn.Name = "EmailDataGridViewTextBoxColumn"
        Me.EmailDataGridViewTextBoxColumn.Width = 130
        '
        'LocationDataGridViewTextBoxColumn
        '
        Me.LocationDataGridViewTextBoxColumn.DataPropertyName = "Location"
        Me.LocationDataGridViewTextBoxColumn.HeaderText = "Location"
        Me.LocationDataGridViewTextBoxColumn.Name = "LocationDataGridViewTextBoxColumn"
        Me.LocationDataGridViewTextBoxColumn.Width = 110
        '
        'AdminNameDataGridViewTextBoxColumn
        '
        Me.AdminNameDataGridViewTextBoxColumn.DataPropertyName = "Admin_Name"
        Me.AdminNameDataGridViewTextBoxColumn.HeaderText = "Admin_Name"
        Me.AdminNameDataGridViewTextBoxColumn.Name = "AdminNameDataGridViewTextBoxColumn"
        Me.AdminNameDataGridViewTextBoxColumn.Width = 130
        '
        'PasswordDataGridViewTextBoxColumn
        '
        Me.PasswordDataGridViewTextBoxColumn.DataPropertyName = "Password"
        Me.PasswordDataGridViewTextBoxColumn.HeaderText = "Password"
        Me.PasswordDataGridViewTextBoxColumn.Name = "PasswordDataGridViewTextBoxColumn"
        Me.PasswordDataGridViewTextBoxColumn.Width = 120
        '
        'AdmininformationBindingSource
        '
        Me.AdmininformationBindingSource.DataMember = "Admininformation"
        Me.AdmininformationBindingSource.DataSource = Me.CARRENTINGSYSTEMDBDataSet12BindingSource
        '
        'CARRENTINGSYSTEMDBDataSet12BindingSource
        '
        Me.CARRENTINGSYSTEMDBDataSet12BindingSource.DataSource = Me.CAR_RENTING_SYSTEM_DBDataSet12
        Me.CARRENTINGSYSTEMDBDataSet12BindingSource.Position = 0
        '
        'CAR_RENTING_SYSTEM_DBDataSet12
        '
        Me.CAR_RENTING_SYSTEM_DBDataSet12.DataSetName = "CAR_RENTING_SYSTEM_DBDataSet12"
        Me.CAR_RENTING_SYSTEM_DBDataSet12.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'AdmininformationTableAdapter
        '
        Me.AdmininformationTableAdapter.ClearBeforeFill = True
        '
        'Addnewadmin
        '
        Me.Addnewadmin.BackColor = System.Drawing.Color.SteelBlue
        Me.Addnewadmin.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Addnewadmin.Font = New System.Drawing.Font("Algerian", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Addnewadmin.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Addnewadmin.Location = New System.Drawing.Point(446, 330)
        Me.Addnewadmin.Name = "Addnewadmin"
        Me.Addnewadmin.Size = New System.Drawing.Size(173, 34)
        Me.Addnewadmin.TabIndex = 5
        Me.Addnewadmin.Text = "Add admin"
        Me.Addnewadmin.UseVisualStyleBackColor = False
        Me.Addnewadmin.Visible = False
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Elephant", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.White
        Me.Label7.Location = New System.Drawing.Point(16, 20)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(0, 21)
        Me.Label7.TabIndex = 7
        '
        'GroupBox3
        '
        Me.GroupBox3.BackColor = System.Drawing.Color.Black
        Me.GroupBox3.Controls.Add(Me.Label7)
        Me.GroupBox3.Controls.Add(Me.Button1)
        Me.GroupBox3.Controls.Add(Me.cancelAdminconfirmBtn)
        Me.GroupBox3.Controls.Add(Me.loginAdmnConfimBtn)
        Me.GroupBox3.Controls.Add(Me.TextAdminPassword)
        Me.GroupBox3.Controls.Add(Me.TextboxAdmin)
        Me.GroupBox3.Controls.Add(Me.Label8)
        Me.GroupBox3.Controls.Add(Me.Label9)
        Me.GroupBox3.Font = New System.Drawing.Font("Elephant", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox3.ForeColor = System.Drawing.Color.White
        Me.GroupBox3.Location = New System.Drawing.Point(393, 27)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(280, 297)
        Me.GroupBox3.TabIndex = 6
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = " ADMIN CONFIRMATION"
        '
        'Button1
        '
        Me.Button1.BackgroundImage = Global.CAR_RENTING_SYSTEM.My.Resources.Resources.Show
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button1.Location = New System.Drawing.Point(203, 152)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(23, 23)
        Me.Button1.TabIndex = 7
        Me.Button1.UseVisualStyleBackColor = True
        '
        'cancelAdminconfirmBtn
        '
        Me.cancelAdminconfirmBtn.BackColor = System.Drawing.Color.Silver
        Me.cancelAdminconfirmBtn.Font = New System.Drawing.Font("Elephant", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cancelAdminconfirmBtn.ForeColor = System.Drawing.Color.Black
        Me.cancelAdminconfirmBtn.Location = New System.Drawing.Point(56, 228)
        Me.cancelAdminconfirmBtn.Name = "cancelAdminconfirmBtn"
        Me.cancelAdminconfirmBtn.Size = New System.Drawing.Size(170, 30)
        Me.cancelAdminconfirmBtn.TabIndex = 5
        Me.cancelAdminconfirmBtn.Text = "CANCEL"
        Me.cancelAdminconfirmBtn.UseVisualStyleBackColor = False
        '
        'loginAdmnConfimBtn
        '
        Me.loginAdmnConfimBtn.BackColor = System.Drawing.Color.Silver
        Me.loginAdmnConfimBtn.Font = New System.Drawing.Font("Elephant", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.loginAdmnConfimBtn.ForeColor = System.Drawing.Color.Black
        Me.loginAdmnConfimBtn.Location = New System.Drawing.Point(56, 191)
        Me.loginAdmnConfimBtn.Name = "loginAdmnConfimBtn"
        Me.loginAdmnConfimBtn.Size = New System.Drawing.Size(170, 31)
        Me.loginAdmnConfimBtn.TabIndex = 4
        Me.loginAdmnConfimBtn.Text = "LOGIN"
        Me.loginAdmnConfimBtn.UseVisualStyleBackColor = False
        '
        'TextAdminPassword
        '
        Me.TextAdminPassword.Font = New System.Drawing.Font("Lucida Sans", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextAdminPassword.Location = New System.Drawing.Point(56, 152)
        Me.TextAdminPassword.Name = "TextAdminPassword"
        Me.TextAdminPassword.Size = New System.Drawing.Size(170, 23)
        Me.TextAdminPassword.TabIndex = 3
        '
        'TextboxAdmin
        '
        Me.TextboxAdmin.Font = New System.Drawing.Font("Lucida Sans", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextboxAdmin.Location = New System.Drawing.Point(56, 97)
        Me.TextboxAdmin.Name = "TextboxAdmin"
        Me.TextboxAdmin.Size = New System.Drawing.Size(170, 23)
        Me.TextboxAdmin.TabIndex = 2
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Cooper Black", 14.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.White
        Me.Label8.Location = New System.Drawing.Point(90, 130)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(104, 21)
        Me.Label8.TabIndex = 1
        Me.Label8.Text = "Password"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Cooper Black", 14.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.White
        Me.Label9.Location = New System.Drawing.Point(80, 73)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(136, 21)
        Me.Label9.TabIndex = 0
        Me.Label9.Text = "Admin Name"
        '
        'AdminRegistration
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.CAR_RENTING_SYSTEM.My.Resources.Resources._2012_audi_r8_gt_100311400_l
        Me.ClientSize = New System.Drawing.Size(1021, 548)
        Me.Controls.Add(Me.Addnewadmin)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.DeleteAdminBTN)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.SubmAdminBtn)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "AdminRegistration"
        Me.Text = "AdminRegistration"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.AdmininformationBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CARRENTINGSYSTEMDBDataSet12BindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CAR_RENTING_SYSTEM_DBDataSet12, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents TextBox6 As TextBox
    Friend WithEvents TextBox5 As TextBox
    Friend WithEvents TextBox4 As TextBox
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents SubmAdminBtn As Button
    Friend WithEvents DeleteAdminBTN As Button
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents CAR_RENTING_SYSTEM_DBDataSet12 As CAR_RENTING_SYSTEM_DBDataSet12
    Friend WithEvents CARRENTINGSYSTEMDBDataSet12BindingSource As BindingSource
    Friend WithEvents AdmininformationBindingSource As BindingSource
    Friend WithEvents AdmininformationTableAdapter As CAR_RENTING_SYSTEM_DBDataSet12TableAdapters.AdmininformationTableAdapter
    Friend WithEvents CampanyNameDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents TelephoneDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents EmailDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents LocationDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents AdminNameDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents PasswordDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents Addnewadmin As Button
    Friend WithEvents Label7 As Label
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents Button1 As Button
    Friend WithEvents cancelAdminconfirmBtn As Button
    Friend WithEvents loginAdmnConfimBtn As Button
    Friend WithEvents TextAdminPassword As TextBox
    Friend WithEvents TextboxAdmin As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
End Class
